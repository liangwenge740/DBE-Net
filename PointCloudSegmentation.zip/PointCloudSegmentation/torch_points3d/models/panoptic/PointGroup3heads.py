import torch
import os
from torch_points_kernels import region_grow
from torch_geometric.data import Data
from torch_scatter import scatter
import random
import numpy as np

from torch_points3d.datasets.segmentation import IGNORE_LABEL
from torch_points3d.models.base_model import BaseModel
from torch_points3d.applications.minkowski import Minkowski
from torch_points3d.core.common_modules import Seq, MLP, FastBatchNorm1d , GenericMLP # 新导入GenericMLP
from torch_points3d.core.losses import offset_loss, instance_iou_loss, mask_loss, instance_ious, discriminative_loss
from torch_points3d.core.data_transform import GridSampling3D
from .structure_3heads import PanopticLabels, PanopticResults #有关数据集label
from torch_points3d.utils import hdbscan_cluster, meanshift_cluster
from torch_points3d.utils import is_list
from torch_points3d.utils import hdbscan_cluster
from os.path import exists, join
from .ply import read_ply, write_ply
import torch.nn.functional as F #新导入
# from torch_points3d.utils.cal_pca import pca_feat #新导入
##############################################################################

import MinkowskiEngine as ME # 新导入
from .focal_loss import FocalLoss
from .axis_aligned_iou_loss import AxisAlignedIoULoss
from torch_points3d.datasets.panoptic.depth_box3d import DepthInstance3DBoxes
from torch_points3d.datasets.panoptic.lidar_box3d import LiDARInstance3DBoxes
from .mink_unet import MinkUNet14B
from torch import nn
from mmcv.cnn import Scale, bias_init_with_prob
from .cross_entropy_loss import CrossEntropyLoss
from mmcv.ops import nms3d, nms3d_normal
import time
from .set_merge import set_mer



class PointGroup3heads(BaseModel):
    __REQUIRED_DATA__ = [
        "pos",
    ]

    __REQUIRED_LABELS__ = list(PanopticLabels._fields)

    def __init__(self, option, model_type, dataset, modules):
        super(PointGroup3heads, self).__init__(option)
        backbone_options = option.get("backbone", {"architecture": "unet"})
        self.Backbone = Minkowski(
            backbone_options.get("architecture", "unet"),
            input_nc=dataset.feature_dimension,
            num_layers=4,
            config=backbone_options.get("config", {}),
        )

        self._scorer_type = option.get("scorer_type", None)
        # cluster_voxel_size = option.get("cluster_voxel_size", 0.05)
        #TODO look at how to do back projection of GridSampling3D
        cluster_voxel_size = False
        if cluster_voxel_size:
            self._voxelizer = GridSampling3D(cluster_voxel_size, quantize_coords=True, mode="mean", return_inverse=True)
        else:
            self._voxelizer = None
        self.ScorerUnet = Minkowski("unet", input_nc=self.Backbone.output_nc, num_layers=4, config=option.scorer_unet)
        self.ScorerEncoder = Minkowski(
            "encoder", input_nc=self.Backbone.output_nc, num_layers=4, config=option.scorer_encoder
        )
        self.ScorerMLP = MLP([self.Backbone.output_nc, self.Backbone.output_nc, self.ScorerUnet.output_nc])
        self.ScorerHead = Seq().append(torch.nn.Linear(self.ScorerUnet.output_nc, 1)).append(torch.nn.Sigmoid())

        self.mask_supervise = option.get("mask_supervise", False)
        if self.mask_supervise:
            self.MaskScore = (
                Seq()
                .append(torch.nn.Linear(self.ScorerUnet.output_nc, self.ScorerUnet.output_nc))
                .append(torch.nn.ReLU())
                .append(torch.nn.Linear(self.ScorerUnet.output_nc, 1))
            )
        self.use_score_net = option.get("use_score_net", True)
        self.use_mask_filter_score_feature = option.get("use_mask_filter_score_feature", False)
        self.use_mask_filter_score_feature_start_epoch = option.get("use_mask_filter_score_feature_start_epoch", 200)
        self.mask_filter_score_feature_thre = option.get("mask_filter_score_feature_thre", 0.5)

        self.cal_iou_based_on_mask = option.get("cal_iou_based_on_mask", False)
        self.cal_iou_based_on_mask_start_epoch = option.get("cal_iou_based_on_mask_start_epoch", 200)

        self.Offset = Seq().append(MLP([self.Backbone.output_nc, self.Backbone.output_nc], bias=False))
        self.Offset.append(torch.nn.Linear(self.Backbone.output_nc, 3))

        ######################暂时注释掉

        self.Embed = Seq().append(MLP([self.Backbone.output_nc, self.Backbone.output_nc], bias=False))
        self.Embed.append(torch.nn.Linear(self.Backbone.output_nc, option.get("embed_dim", 5)))

        ###############################
        self.Semantic = (
            Seq()
            # 暂时注释掉
            # .append(MLP([self.Backbone.output_nc, self.Backbone.output_nc], bias=False))
            # .append(torch.nn.Linear(self.Backbone.output_nc, dataset.num_classes))
            .append(MLP([self.Backbone.output_nc, 4], bias=False))
            .append(torch.nn.Linear(4, dataset.num_classes))
        )
        self.LogSoftLay = (
            Seq()
            .append(torch.nn.LogSoftmax(dim=-1))
        )
        self.loss_names = ["loss", 'bbox1_loss', 'cls1_loss',"inst1_loss" ,"offset_norm_loss", "offset_dir_loss",  "ins_loss", "ins_var_loss", "ins_dist_loss", "ins_reg_loss","semantic_loss", "score_loss", "mask_loss"] ####新增ray_losses 'bbox_loss' 'cls_loss'
        self.use_binary_loss = option.get("use_binary_loss", False)
        if self.use_binary_loss:
            self.BiSemantic = (
                Seq()
                .append(torch.nn.Linear(dataset.num_classes, 2))
                .append(torch.nn.LogSoftmax(dim=-1))
            )
            self.loss_names = ["loss", 'bbox1_loss', 'cls1_loss',"inst1_loss","offset_norm_loss", "offset_dir_loss",  "ins_loss", "ins_var_loss", "ins_dist_loss", "ins_reg_loss","semantic_loss", "score_loss", "mask_loss", "semantic_loss_bi"]####新增ray_losses
        
        stuff_classes = dataset.stuff_classes
        if is_list(stuff_classes):
            stuff_classes = torch.Tensor(stuff_classes).long()

        # 由于没有thing_classes，因此先注释掉
        # thing_classes = dataset.thing_classes
        # if is_list(thing_classes):
        #     thing_classes = torch.Tensor(thing_classes).long()

        self._stuff_classes = torch.cat([torch.tensor([IGNORE_LABEL]), stuff_classes])
        
        # self._thing_classes = thing_classes

        
        self._weight_per_point = option.get("weight_per_point", None)



        ###########################################bbox的初始化

        self.n_classes = 1 # 只有树木一个类别

        # 如果重新用回来记得把下面初始化的注释取消掉

        self.reg_conv = ME.MinkowskiConvolution(
            self.Backbone.output_nc, 6, kernel_size=1, bias=True, dimension=3)
        self.cls_conv = ME.MinkowskiConvolution(
            self.Backbone.output_nc, self.n_classes , kernel_size=1, bias=True, dimension=3)
        


        # self.reg_conv = torch.nn.Sequential(ME.MinkowskiConvolution(self.Backbone.output_nc, self.Backbone.output_nc, kernel_size=1, bias=True, dimension=3),
        #                                     ME.MinkowskiBatchNorm(self.Backbone.output_nc),
        #                                     ME.MinkowskiReLU(),
        #                                     ME.MinkowskiConvolution(self.Backbone.output_nc, 6, kernel_size=1, bias=True, dimension=3))
     


        # self.cls_conv = torch.nn.Sequential(ME.MinkowskiConvolution(self.Backbone.output_nc, self.Backbone.output_nc, kernel_size=1, bias=True, dimension=3),
        #                                     ME.MinkowskiBatchNorm(self.Backbone.output_nc),
        #                                     ME.MinkowskiReLU(),
        #                                     ME.MinkowskiConvolution(self.Backbone.output_nc, self.n_classes, kernel_size=1, bias=True, dimension=3))


        self.first_assigner = S3DISAssigner(top_pts_threshold = 8, label2level=[0]) 

        self.voxel_size = option.get("voxel_size", 0.2)
        #self.batch_size = 4

        self.cls_loss = FocalLoss()
        self.bbox_loss = AxisAlignedIoULoss(mode="diou")

        self.padding = 0.08  #0.08

        self.second_assigner = MaxIoU3DAssigner(.25) # 默认为0.25
        self.num_rois = 1

        self.roi_extractor = Mink3DRoIExtractor(self.voxel_size,self.padding,min_pts_threshold=50)  #min_pts_threshold默认为10

        #self.unet = MinkUNet14B(in_channels=16, out_channels= self.n_classes + 1, D=3) # out_channels=len(class_names) + 1

        # 尝试使用普通的MLP，因此将这个注释掉，如果效果不好再加回来，记得后面forward的unet可能也要改变
        self.unet = Minkowski("unet", input_nc=self.Backbone.output_nc, output_nc=2, num_layers=4, config=option.pre_unet) # out_channels=len(class_names) + 1
        
        # self.unet = Seq().append(MLP([self.Backbone.output_nc, self.Backbone.output_nc], bias=True))
        # self.unet.append(torch.nn.Linear(self.Backbone.output_nc, 2))

        self.init_weights()

        self.inst_loss = CrossEntropyLoss(use_sigmoid=True)


        self.test_cfg=dict(
                        nms_pre= 1000, # 在应用 NMS 之前，​保留得分最高的前 1000 个候选框。 # 默认为1000
                        iou_thr= 0.4,
                        score_thr= 0.1, # 默认为0.05 将类别得分低于该值的检测框给pass掉
                        binary_score_thr= 0.5) # 默认为0.2 使用0.5
        
        


    def init_weights(self):
        nn.init.normal_(self.reg_conv.kernel, std=0.01)
        nn.init.normal_(self.cls_conv.kernel, std=0.01)
        nn.init.constant_(self.cls_conv.bias, bias_init_with_prob(0.01))

    def set_batch_size(self, batch_size):
        self.batch_size = batch_size


        ########################################################################

    def get_opt_mergeTh(self):
        """returns configuration"""
        if self.opt.block_merge_th:
            return self.opt.block_merge_th
        else:
            return 0.01 # 默认0.01
    
    def set_input(self, data, device):
        self.raw_pos = data.pos.to(device)
        self.input = data

        temp = [torch.tensor(i).to(device) for i in data['gt_labels_3d']]
        temp1 = [torch.tensor(i).to(device) for i in data['batch_ins_label']]

        # print('gt_labels_3d',data['gt_labels_3d'])
        # print('temp',temp)
        # print('gt_bboxes_3d',data['gt_bboxes_3d'])

        all_labels = {l: data[l].to(device) for l in self.__REQUIRED_LABELS__ if l not in ['gt_bboxes_3d','gt_labels_3d','batch_ins_label']} # 进行修改
        all_labels['gt_bboxes_3d'] = data['gt_bboxes_3d']
        all_labels['gt_labels_3d'] = temp
        all_labels['batch_ins_label'] = temp1
        
        self.labels = PanopticLabels(**all_labels)

        #print('self.raw_pos',len(self.raw_pos))
        #print('self.input_coord',len(self.input.coords))





    def forward(self, epoch=-1, **kwargs):
        # Backbone

        #print('self.test_cfg',self.test_cfg)
        ######## 这里需要进行修改

        #print('self.input',self.input)
        backbone , sparse_tensor = self.Backbone(self.input) # [N, 16]
        
        backbone_features = backbone.x
        
        #print('backbone_features',backbone_features)
        
        # backbone_features = self.Backbone(self.input).x 先注释掉

        ######################################################

        # Semantic, offset and embedding heads

        ######################## ！！！为了节省内存不使用

        #semantic_logits = self.Semantic(backbone_features) # [N, 9]
        semantic_logits = self.Semantic(backbone_features.detach())
        semantic_logits = self.LogSoftLay(semantic_logits)
        bi_semantic_logits = None
        if self.use_binary_loss:
            bi_semantic_logits = self.BiSemantic(semantic_logits)

        # start_time1 = time.time()

        offset_logits = self.Offset(backbone_features) # [N, 3]

        # end_time1 = time.time() 
        # print(f"offset_logits模块运行耗时: {end_time1 - start_time1:.4f} 秒")



        ###########################

        # start_time1 = time.time()

        embed_logits = self.Embed(backbone_features) # [N, 5] 

        # end_time1 = time.time() 
        # print(f"embed_logits模块运行耗时: {end_time1 - start_time1:.4f} 秒")


        
        ###########################################

        ################################## shpe的前向训练

        ins = self.labels.instance_labels_no_stuff.clone().detach().reshape(-1,1)
        sem = self.labels.semantic_labels_no_stuff.clone().detach().reshape(-1,1)

        targets = torch.cat((ins,sem),dim=-1)
        

        #print('**kwargs',kwargs)
        # start_time = time.time()

        # start_time1 = time.time()

        losses, cluster_bbox, rois_test = self.forward_train(sparse_tensor, 
                           targets,
                           self.labels.gt_bboxes_3d, 
                           self.labels.gt_labels_3d, 
                           self.labels.batch_ins_label,
                           #1,
                           self.batch_size,
                           epoch, #临时增加epoch方便观察数据
                           self.raw_pos)
        
        # end_time1 = time.time() 
        # print(f"bbox模块运行耗时: {end_time1 - start_time1:.4f} 秒")
        
        # print('rois_test',rois_test)
        # print('self.raw_pos',self.raw_pos)
        
        # end_time = time.time() 
        # print(f"bbox模块运行耗时: {end_time - start_time:.4f} 秒")


        ########################################################




        # Grouping and scoring
        cluster_scores = None
        mask_scores = None
        all_clusters = None # list of clusters (point idx)
        cluster_type = None # 0 for cluster, 1 for vote


        ################################################################################
        
        if self.use_score_net: # and epoch > self.opt.prepare_epoch:
            if epoch > self.opt.prepare_epoch:   # Active by default epoch > -1: #
                if self.opt.cluster_type == 1:
                    all_clusters, cluster_type = self._cluster(semantic_logits, offset_logits)
                elif self.opt.cluster_type == 2:
                    all_clusters, cluster_type = self._cluster2(semantic_logits, offset_logits)
                elif self.opt.cluster_type == 3:
                    all_clusters, cluster_type = self._cluster3(semantic_logits, embed_logits)
                elif self.opt.cluster_type == 4:
                    all_clusters, cluster_type = self._cluster4(semantic_logits, embed_logits)
                elif self.opt.cluster_type == 5:
                    all_clusters, cluster_type = self._cluster5(semantic_logits, offset_logits, embed_logits)
                elif self.opt.cluster_type == 6:
                    all_clusters, cluster_type = self._cluster6(semantic_logits, offset_logits, embed_logits)
                elif self.opt.cluster_type == 7: #set1_classes5/set2/set3
                    all_clusters, cluster_type = self._cluster7(semantic_logits, offset_logits, embed_logits)

                ######################新增选项


                elif self.opt.cluster_type == 8:
                    all_clusters, cluster_type = self._cluster8(semantic_logits, embed_logits, cluster_bbox)



                elif self.opt.cluster_type == 9:
                    all_clusters, cluster_type = self._cluster9(cluster_bbox)

                elif self.opt.cluster_type == 11:
                    all_clusters, cluster_type = self._cluster11(semantic_logits, offset_logits, embed_logits)

                elif self.opt.cluster_type == 10:
                    all_clusters, cluster_type = self._cluster10(semantic_logits, offset_logits, embed_logits)

                elif self.opt.cluster_type == 12:
                    all_clusters, cluster_type = self._cluster12(semantic_logits, offset_logits, cluster_bbox)



                ##########################################################
                # all_clusters为一个列表，列表里面每一个tensor包含一个实例的点云索引
                # cluster_type表示聚类的类别

                # print('all_clusters',len(all_clusters))
                # print('cluster_type',len(cluster_type))

                ######################################### 将scorenet与聚类过程分开
                if epoch > self.opt.prepare_epoch:

                    if len(all_clusters):
                        cluster_scores, mask_scores = self._compute_score(epoch, all_clusters, backbone_features, semantic_logits)
                        #cluster_scores, mask_scores = self._compute_score_batch(epoch, all_clusters, cluster_type, backbone_features, semantic_logits)
                        #cluster_scores, mask_scores = self._compute_real_score(epoch, all_clusters, cluster_type, backbone_features, semantic_logits)

        else:
            with torch.no_grad():
                if epoch % 1 == 0:
                    if self.opt.cluster_type == 1:
                        all_clusters, cluster_type = self._cluster(semantic_logits, offset_logits)
                    elif self.opt.cluster_type == 2:
                        all_clusters, cluster_type = self._cluster2(semantic_logits, offset_logits)
                    elif self.opt.cluster_type == 3:
                        all_clusters, cluster_type = self._cluster3(semantic_logits, embed_logits)
                    elif self.opt.cluster_type == 4:
                        all_clusters, cluster_type = self._cluster4(semantic_logits, embed_logits)
                    elif self.opt.cluster_type == 5:
                        all_clusters, cluster_type = self._cluster5(semantic_logits, offset_logits, embed_logits)
                    elif self.opt.cluster_type == 6:
                        all_clusters, cluster_type = self._cluster6(semantic_logits, offset_logits, embed_logits)
                    elif self.opt.cluster_type == 7:
                        all_clusters, cluster_type = self._cluster7(semantic_logits, offset_logits, embed_logits)

                        
                    ######################新增选项

                    elif self.opt.cluster_type == 8:
                        all_clusters, cluster_type = self._cluster8(semantic_logits, embed_logits, cluster_bbox)




                    elif self.opt.cluster_type == 9:
                        all_clusters, cluster_type = self._cluster9(cluster_bbox)

                    elif self.opt.cluster_type == 11:
                        all_clusters, cluster_type = self._cluster11(semantic_logits, offset_logits, embed_logits)

                    elif self.opt.cluster_type == 10:
                        all_clusters, cluster_type = self._cluster10(semantic_logits, offset_logits, embed_logits)

                    elif self.opt.cluster_type == 12:
                        all_clusters, cluster_type = self._cluster12(semantic_logits, offset_logits, cluster_bbox)

                    ##########################################################

                
        self.output = PanopticResults(
            semantic_logits=semantic_logits,  
            bi_semantic_logits=bi_semantic_logits,  
            offset_logits=offset_logits,
            embed_logits=embed_logits,
            clusters=all_clusters,
            cluster_scores=cluster_scores,
            mask_scores=mask_scores,
            cluster_type=cluster_type,
            losses = losses, ####################### 新增加
            rois_test = rois_test, ##########新增加
            raw_pos = self.raw_pos ##########新增加
        )

        # Sets visual data for debugging
        #with torch.no_grad():
        #    self._dump_visuals(epoch)

    def _cluster(self, semantic_logits, offset_logits):
        """ Compute clusters from positions and votes """
        predicted_labels = torch.max(semantic_logits, 1)[1] # [N]
        clusters_votes = region_grow(
            self.raw_pos + offset_logits,
            predicted_labels,
            self.input.batch.to(self.device),
            ignore_labels=self._stuff_classes.to(self.device),
            radius=self.opt.cluster_radius_search,
            nsample=200,
            min_cluster_size=10
        )
        #clusters_votes = []

        all_clusters = clusters_votes
        all_clusters = [c.to(self.device) for c in all_clusters]
        cluster_type = torch.zeros(len(all_clusters), dtype=torch.uint8).to(self.device)
        return all_clusters, cluster_type
    
    def _cluster2(self, semantic_logits, offset_logits):
        """ Compute clusters from positions and votes """
        predicted_labels = torch.max(semantic_logits, 1)[1] # [N]
        clusters_pos = region_grow(
            self.raw_pos,
            predicted_labels,
            self.input.batch.to(self.device),
            ignore_labels=self._stuff_classes.to(self.device),
            radius=self.opt.cluster_radius_search,
            min_cluster_size=10
        )
        #clusters_pos = []
        clusters_votes = region_grow(
            self.raw_pos + offset_logits,
            predicted_labels,
            self.input.batch.to(self.device),
            ignore_labels=self._stuff_classes.to(self.device),
            radius=self.opt.cluster_radius_search,
            nsample=200,
            min_cluster_size=10
        )
        #clusters_votes = []

        all_clusters = clusters_pos + clusters_votes
        all_clusters = [c.to(self.device) for c in all_clusters]
        cluster_type = torch.zeros(len(all_clusters), dtype=torch.uint8).to(self.device)
        if len(clusters_pos):
            cluster_type[len(clusters_pos) :] = 1
        return all_clusters, cluster_type

    #clustering based on embedding features + meanshift
    def _cluster3(self, semantic_logits, embed_logits):
        """ Compute clusters"""
        #remove stuff points
        N = embed_logits.shape[0]  #.cpu().detach().numpy().shape[0]
        predicted_labels = torch.max(semantic_logits, 1)[1] #.cpu().detach().numpy() # [N]
        ind = torch.arange(0, N)
        unique_predicted_labels = torch.unique(predicted_labels) #np.unique(predicted_labels)
        ignore_labels=self._stuff_classes.to(self.device)  #.cpu().detach().numpy()
        label_mask = torch.ones(predicted_labels.shape[0], dtype=torch.bool) #.cpu().detach().numpy()
        for l in unique_predicted_labels:
            if l in ignore_labels:
                # Build clusters for a given label (ignore other points)
                label_mask_l = predicted_labels == l
                label_mask[label_mask_l] = False
        local_ind = ind[label_mask]
        label_batch = self.input.batch[label_mask]  #.cpu().detach().numpy()
        unique_in_batch = torch.unique(label_batch)
        
        #Clustering based on embeddings
        embeds_u = embed_logits[label_mask]  #.cpu().detach().numpy()
        
        #clusters_embed, cluster_type_embeds = hdbscan_cluster.cluster_single(embeds_u, unique_in_batch, label_batch, local_ind, 0)
        clusters_embed, cluster_type_embeds = meanshift_cluster.cluster_single(embeds_u, unique_in_batch, label_batch, local_ind, 0, self.opt.bandwidth)

        ###### Combine the two groups of clusters ######
        all_clusters = clusters_embed
        all_clusters = [c.to(self.device) for c in all_clusters]
        cluster_type = torch.zeros(len(all_clusters), dtype=torch.uint8).to(self.device)
        return all_clusters, cluster_type
    
    #clustering based on embedding features + meanshift U original coordinates + regiongrowing
    def _cluster4(self, semantic_logits, embed_logits):
        """ Compute clusters from positions and votes """

        ###### Cluster using original position with predicted semantic labels ######
        predicted_labels = torch.max(semantic_logits, 1)[1] # [N]
        clusters_pos = []
        clusters_pos = region_grow(
            self.raw_pos,
            predicted_labels,
            self.input.batch.to(self.device),
            ignore_labels=self._stuff_classes.to(self.device),
            radius=self.opt.cluster_radius_search,
            min_cluster_size=10
        )
        ###### Cluster using embedding without predicted semantic labels ######
        #remove stuff points
        N = embed_logits.shape[0]  #.cpu().detach().numpy().shape[0]
        ind = torch.arange(0, N)
        unique_predicted_labels = torch.unique(predicted_labels) #np.unique(predicted_labels)
        ignore_labels=self._stuff_classes.to(self.device)  #.cpu().detach().numpy()
        label_mask = torch.ones(predicted_labels.shape[0], dtype=torch.bool) #.cpu().detach().numpy()
        for l in unique_predicted_labels:
            if l in ignore_labels:
                # Build clusters for a given label (ignore other points)
                label_mask_l = predicted_labels == l
                label_mask[label_mask_l] = False
        local_ind = ind[label_mask]
        label_batch = self.input.batch[label_mask]  #.cpu().detach().numpy()
        unique_in_batch = torch.unique(label_batch)
        
        #Clustering based on embeddings
        embeds_u = embed_logits[label_mask]  #.cpu().detach().numpy()
        clusters_embed, cluster_type_embeds = meanshift_cluster.cluster_single(embeds_u, unique_in_batch, label_batch, local_ind, 1, self.opt.bandwidth)


        ###### Combine the two groups of clusters ######
        all_clusters = []
        cluster_type = []
        all_clusters = all_clusters + clusters_pos
        all_clusters = all_clusters + clusters_embed
        cluster_type = cluster_type + list(np.zeros(len(clusters_pos), dtype=np.uint8))
        cluster_type = cluster_type + cluster_type_embeds
        all_clusters = [c.clone().detach().to(self.device) for c in all_clusters]
        cluster_type = torch.tensor(cluster_type).to(self.device)
        return all_clusters, cluster_type
    
    #clustering based on embedding features + meanshift U shifted coordinates + regiongrowing
    def _cluster5(self, semantic_logits, offset_logits, embed_logits):
        """ Compute clusters from positions and votes """
        ###### Cluster using original position with predicted semantic labels ######
        predicted_labels = torch.max(semantic_logits, 1)[1] # [N]
        clusters_pos = []
        clusters_pos = region_grow(
            self.raw_pos + offset_logits,
            predicted_labels,
            self.input.batch.to(self.device),
            ignore_labels=self._stuff_classes.to(self.device),
            radius=self.opt.cluster_radius_search,
            nsample=200,
            min_cluster_size=10
        )
        ###### Cluster using embedding without predicted semantic labels ######
        #remove stuff points
        N = embed_logits.shape[0]  #.cpu().detach().numpy().shape[0]
        ind = torch.arange(0, N)
        unique_predicted_labels = torch.unique(predicted_labels) #np.unique(predicted_labels)
        ignore_labels=self._stuff_classes.to(self.device)  #.cpu().detach().numpy()
        label_mask = torch.ones(predicted_labels.shape[0], dtype=torch.bool) #.cpu().detach().numpy()
        for l in unique_predicted_labels:
            if l in ignore_labels:
                # Build clusters for a given label (ignore other points)
                label_mask_l = predicted_labels == l
                label_mask[label_mask_l] = False
        local_ind = ind[label_mask]
        label_batch = self.input.batch[label_mask]  #.cpu().detach().numpy()
        unique_in_batch = torch.unique(label_batch)
        
        #Clustering based on embeddings
        embeds_u = embed_logits[label_mask]  #.cpu().detach().numpy()
        clusters_embed, cluster_type_embeds = meanshift_cluster.cluster_single(embeds_u, unique_in_batch, label_batch, local_ind, 1, self.opt.bandwidth)


        ###### Combine the two groups of clusters ######
        all_clusters = []
        cluster_type = []
        all_clusters = all_clusters + clusters_pos
        all_clusters = all_clusters + clusters_embed
        cluster_type = cluster_type + list(np.zeros(len(clusters_pos), dtype=np.uint8))
        cluster_type = cluster_type + cluster_type_embeds
        all_clusters = [c.clone().detach().to(self.device) for c in all_clusters]
        cluster_type = torch.tensor(cluster_type).to(self.device)
        return all_clusters, cluster_type

    def _cluster6(self, semantic_logits, offset_logits, embed_logits):
        """ Compute clusters from positions and votes """
        predicted_labels = torch.max(semantic_logits, 1)[1] # [N]
        clusters_pos = region_grow(
            self.raw_pos,
            predicted_labels,
            self.input.batch.to(self.device),
            ignore_labels=self._stuff_classes.to(self.device),
            radius=self.opt.cluster_radius_search,
            min_cluster_size=10
        )
        #clusters_pos = []
        clusters_votes = region_grow(
            self.raw_pos + offset_logits,
            predicted_labels,
            self.input.batch.to(self.device),
            ignore_labels=self._stuff_classes.to(self.device),
            radius=self.opt.cluster_radius_search,
            nsample=200,
            min_cluster_size=10
        )
        ###### Cluster using embedding without predicted semantic labels ######
        #remove stuff points
        N = embed_logits.shape[0]  #.cpu().detach().numpy().shape[0]
        ind = torch.arange(0, N)
        unique_predicted_labels = torch.unique(predicted_labels) #np.unique(predicted_labels)
        ignore_labels=self._stuff_classes.to(self.device)  #.cpu().detach().numpy()
        label_mask = torch.ones(predicted_labels.shape[0], dtype=torch.bool) #.cpu().detach().numpy()
        for l in unique_predicted_labels:
            if l in ignore_labels:
                # Build clusters for a given label (ignore other points)
                label_mask_l = predicted_labels == l
                label_mask[label_mask_l] = False
        local_ind = ind[label_mask]
        label_batch = self.input.batch[label_mask]  #.cpu().detach().numpy()
        unique_in_batch = torch.unique(label_batch)
        
        #Clustering based on embeddings
        embeds_u = embed_logits[label_mask]  #.cpu().detach().numpy()
        clusters_embed, cluster_type_embeds = meanshift_cluster.cluster_single(embeds_u, unique_in_batch, label_batch, local_ind, 2, self.opt.bandwidth)


        ###### Combine the two groups of clusters ######
        all_clusters = []
        cluster_type = []
        all_clusters = all_clusters + clusters_pos
        all_clusters = all_clusters + clusters_votes
        all_clusters = all_clusters + clusters_embed
        cluster_type = cluster_type + list(np.zeros(len(clusters_pos), dtype=np.uint8))
        cluster_type = cluster_type + list(np.ones(len(clusters_votes), dtype=np.uint8))
        cluster_type = cluster_type + cluster_type_embeds
        all_clusters = [c.clone().detach().to(self.device) for c in all_clusters]
        cluster_type = torch.tensor(cluster_type).to(self.device)

        return all_clusters, cluster_type


    def _cluster7(self, semantic_logits, offset_logits, embed_logits):
        """ Compute clusters from positions and votes """
        ###### Cluster using original position with predicted semantic labels ######
        predicted_labels = torch.max(semantic_logits, 1)[1] # [N]
        predicted_labels_copy = predicted_labels.detach().clone()
        #map the predicted semantic labels to the same label : trees
        min_thing_label = torch.min(self._thing_classes)
        for i in self._thing_classes:
            predicted_labels[predicted_labels_copy==i] = min_thing_label.to(self.device)
        clusters_pos = []
        clusters_pos = region_grow(
            self.raw_pos + offset_logits,
            predicted_labels,
            self.input.batch.to(self.device),
            ignore_labels=self._stuff_classes.to(self.device),
            radius=self.opt.cluster_radius_search,
            nsample=200,
            min_cluster_size=10
        )
        ###### Cluster using embedding without predicted semantic labels ######
        #remove stuff points
        N = embed_logits.shape[0]  #.cpu().detach().numpy().shape[0]
        ind = torch.arange(0, N)
        unique_predicted_labels = torch.unique(predicted_labels) #np.unique(predicted_labels)
        ignore_labels=self._stuff_classes.to(self.device)  #.cpu().detach().numpy()
        label_mask = torch.ones(predicted_labels.shape[0], dtype=torch.bool) #.cpu().detach().numpy()
        for l in unique_predicted_labels:
            if l in ignore_labels:
                # Build clusters for a given label (ignore other points)
                label_mask_l = predicted_labels == l
                label_mask[label_mask_l] = False
        local_ind = ind[label_mask]
        label_batch = self.input.batch[label_mask]  #.cpu().detach().numpy()
        unique_in_batch = torch.unique(label_batch)
        
        #Clustering based on embeddings
        embeds_u = embed_logits[label_mask]  #.cpu().detach().numpy()
        clusters_embed, cluster_type_embeds = meanshift_cluster.cluster_single(embeds_u, unique_in_batch, label_batch, local_ind, 1, self.opt.bandwidth)


        ###### Combine the two groups of clusters ######
        all_clusters = []
        cluster_type = []
        all_clusters = all_clusters + clusters_pos
        all_clusters = all_clusters + clusters_embed
        cluster_type = cluster_type + list(np.zeros(len(clusters_pos), dtype=np.uint8))

        cluster_type = cluster_type + cluster_type_embeds



        all_clusters = [c.clone().detach().to(self.device) for c in all_clusters]
        cluster_type = torch.tensor(cluster_type).to(self.device)
        return all_clusters, cluster_type
    

    ###############################################新增聚类



    def _cluster8(self, semantic_logits, embed_logits, cluster_bbox):
        """ Compute clusters"""


        #remove stuff points
        N = embed_logits.shape[0]  #.cpu().detach().numpy().shape[0]
        predicted_labels = torch.max(semantic_logits, 1)[1] #.cpu().detach().numpy() # [N]
        ind = torch.arange(0, N)
        unique_predicted_labels = torch.unique(predicted_labels) #np.unique(predicted_labels)
        ignore_labels=self._stuff_classes.to(self.device)  #.cpu().detach().numpy()
        label_mask = torch.ones(predicted_labels.shape[0], dtype=torch.bool) #.cpu().detach().numpy()
        for l in unique_predicted_labels:
            if l in ignore_labels:
                # Build clusters for a given label (ignore other points)
                label_mask_l = predicted_labels == l
                label_mask[label_mask_l] = False
        local_ind = ind[label_mask]
        label_batch = self.input.batch[label_mask]  #.cpu().detach().numpy()
        unique_in_batch = torch.unique(label_batch)
        
        #Clustering based on embeddings
        embeds_u = embed_logits[label_mask]  #.cpu().detach().numpy()

        # start_time1 = time.time()
        
        #clusters_embed, cluster_type_embeds = hdbscan_cluster.cluster_single(embeds_u, unique_in_batch, label_batch, local_ind, 0)
        clusters_embed, cluster_type_embeds = meanshift_cluster.cluster_single(embeds_u, unique_in_batch, label_batch, local_ind, 0, self.opt.bandwidth)

        # end_time1 = time.time() 
        # print(f"clustering模块运行耗时: {end_time1 - start_time1:.4f} 秒")

        ###### Combine the two groups of clusters ######
        all_clusters = []
        cluster_type = []

        #####
        # 计划在这里插入set_merge
        # print('cluster_box个数',len(cluster_bbox))
        # print('clusters_embed个数',len(clusters_embed))

        # cluster_bbox = set_mer(cluster_bbox, self.raw_pos, self.input.batch, N1=2000, r_min = 1, a=0.3)
        # clusters_embed = set_mer(clusters_embed, self.raw_pos, self.input.batch, N1=2000, r_min = 1, a=0.3)


        #####




        all_clusters = all_clusters + cluster_bbox # cluster_bbox放在cuda
        all_clusters = all_clusters + clusters_embed # clusters_embed似乎放在cpu
        
        cluster_type = cluster_type + list(np.zeros(len(cluster_bbox), dtype=np.uint8))


        cluster_type = cluster_type + cluster_type_embeds # 暂时注释掉
        #cluster_type = cluster_type + list(np.ones(len(clusters_embed), dtype=np.uint8))



        all_clusters = [c.clone().detach().to(self.device) for c in all_clusters]
        cluster_type = torch.tensor(cluster_type).to(self.device)

        return all_clusters, cluster_type
    







    def _cluster9(self, cluster_bbox):

        all_clusters = cluster_bbox
        all_clusters = [c.to(self.device) for c in all_clusters]
        cluster_type = torch.zeros(len(all_clusters), dtype=torch.uint8).to(self.device)

        return all_clusters, cluster_type
    




    # 2 类别
    def _cluster10(self, semantic_logits, offset_logits, embed_logits): 
        """ Compute clusters from positions and votes """
        ###### Cluster using original position with predicted semantic labels ######
        predicted_labels = torch.max(semantic_logits, 1)[1] # [N]
        clusters_pos = []
        clusters_pos = region_grow(
            self.raw_pos + offset_logits,
            predicted_labels,
            self.input.batch.to(self.device),
            ignore_labels=self._stuff_classes.to(self.device),
            radius=self.opt.cluster_radius_search,
            nsample=200,
            min_cluster_size=10
        )
        ###### Cluster using embedding without predicted semantic labels ######
        #remove stuff points
        N = embed_logits.shape[0]  #.cpu().detach().numpy().shape[0]
        ind = torch.arange(0, N)
        unique_predicted_labels = torch.unique(predicted_labels) #np.unique(predicted_labels)
        ignore_labels=self._stuff_classes.to(self.device)  #.cpu().detach().numpy()
        label_mask = torch.ones(predicted_labels.shape[0], dtype=torch.bool) #.cpu().detach().numpy()
        for l in unique_predicted_labels:
            if l in ignore_labels:
                # Build clusters for a given label (ignore other points)
                label_mask_l = predicted_labels == l
                label_mask[label_mask_l] = False
        local_ind = ind[label_mask]
        label_batch = self.input.batch[label_mask]  #.cpu().detach().numpy()
        unique_in_batch = torch.unique(label_batch)
        
        #Clustering based on embeddings
        embeds_u = embed_logits[label_mask]  #.cpu().detach().numpy()
        clusters_embed, cluster_type_embeds = meanshift_cluster.cluster_single(embeds_u, unique_in_batch, label_batch, local_ind, 1, self.opt.bandwidth)


        ###### Combine the two groups of clusters ######
        all_clusters = []
        cluster_type = []
        all_clusters = all_clusters + clusters_pos
        all_clusters = all_clusters + clusters_embed
        cluster_type = cluster_type + list(np.zeros(len(clusters_pos), dtype=np.uint8))
        cluster_type = cluster_type + cluster_type_embeds
        all_clusters = [c.clone().detach().to(self.device) for c in all_clusters]
        cluster_type = torch.tensor(cluster_type).to(self.device)
        return all_clusters, cluster_type
    
    

    # 5 类别
    def _cluster11(self, semantic_logits, offset_logits, embed_logits):
        """ Compute clusters from positions and votes """
        ###### Cluster using original position with predicted semantic labels ######
        predicted_labels = torch.max(semantic_logits, 1)[1] # [N]
        predicted_labels_copy = predicted_labels.detach().clone()
        #map the predicted semantic labels to the same label : trees

        ## 修改
        thing_classes = torch.Tensor([2,3,4]).long()
        min_thing_label = torch.min(thing_classes) # self._thing_classes为2，3，4
        for i in thing_classes:
            predicted_labels[predicted_labels_copy==i] = min_thing_label.to(self.device)


        clusters_pos = []

        # start_time2 = time.time()


        clusters_pos = region_grow(
            self.raw_pos + offset_logits,
            predicted_labels,
            self.input.batch.to(self.device),
            ignore_labels=self._stuff_classes.to(self.device),
            radius=self.opt.cluster_radius_search,
            nsample=200,
            min_cluster_size=10
        )

        # end_time2 = time.time()
        # print(f"offset_cluster模块运行耗时: {end_time2 - start_time2:.4f} 秒")




        ###### Cluster using embedding without predicted semantic labels ######
        #remove stuff points
        N = embed_logits.shape[0]  #.cpu().detach().numpy().shape[0]
        ind = torch.arange(0, N)
        unique_predicted_labels = torch.unique(predicted_labels) #np.unique(predicted_labels)
        ignore_labels=self._stuff_classes.to(self.device)  #.cpu().detach().numpy()
        label_mask = torch.ones(predicted_labels.shape[0], dtype=torch.bool) #.cpu().detach().numpy()
        for l in unique_predicted_labels:
            if l in ignore_labels:
                # Build clusters for a given label (ignore other points)
                label_mask_l = predicted_labels == l
                label_mask[label_mask_l] = False
        local_ind = ind[label_mask]
        label_batch = self.input.batch[label_mask]  #.cpu().detach().numpy()
        unique_in_batch = torch.unique(label_batch)
        
        #Clustering based on embeddings
        embeds_u = embed_logits[label_mask]  #.cpu().detach().numpy()
        clusters_embed, cluster_type_embeds = meanshift_cluster.cluster_single(embeds_u, unique_in_batch, label_batch, local_ind, 1, self.opt.bandwidth)


        ###### Combine the two groups of clusters ######
        all_clusters = []
        cluster_type = []
        all_clusters = all_clusters + clusters_pos
        all_clusters = all_clusters + clusters_embed
        cluster_type = cluster_type + list(np.zeros(len(clusters_pos), dtype=np.uint8))
        cluster_type = cluster_type + cluster_type_embeds
        all_clusters = [c.clone().detach().to(self.device) for c in all_clusters]
        cluster_type = torch.tensor(cluster_type).to(self.device)
        return all_clusters, cluster_type
    



    

    # 5 类别
    def _cluster12(self, semantic_logits, offset_logits, cluster_bbox): 
        """ Compute clusters from positions and votes """
        ###### Cluster using original position with predicted semantic labels ######
        predicted_labels = torch.max(semantic_logits, 1)[1] # [N]
        predicted_labels_copy = predicted_labels.detach().clone()
        #map the predicted semantic labels to the same label : trees

        ## 修改
        thing_classes = torch.Tensor([2,3,4]).long()
        min_thing_label = torch.min(thing_classes) # self._thing_classes为2，3，4
        for i in thing_classes:
            predicted_labels[predicted_labels_copy==i] = min_thing_label.to(self.device)


        clusters_pos = []

        # start_time2 = time.time()


        clusters_pos = region_grow(
            self.raw_pos + offset_logits,
            predicted_labels,
            self.input.batch.to(self.device),
            ignore_labels=self._stuff_classes.to(self.device),
            radius=self.opt.cluster_radius_search,
            nsample=200,
            min_cluster_size=10
        )


        ###### Combine the two groups of clusters ######
        all_clusters = []
        cluster_type = []
        all_clusters = all_clusters + clusters_pos
        all_clusters = all_clusters + cluster_bbox
        cluster_type = cluster_type + list(np.zeros(len(clusters_pos), dtype=np.uint8))
        cluster_type = cluster_type + list(np.zeros(len(cluster_bbox), dtype=np.uint8))
        all_clusters = [c.clone().detach().to(self.device) for c in all_clusters]
        cluster_type = torch.tensor(cluster_type).to(self.device)
        return all_clusters, cluster_type
    
    
    






    ################################################################



    
    def _compute_score(self, epoch, all_clusters, backbone_features, semantic_logits):
        """ Score the clusters """
        mask_scores = None
        if self._scorer_type: # unet
            # Assemble batches
            x = [] # backbone features
            coords = [] # input coords
            batch = [] 
            pos = []
            for i, cluster in enumerate(all_clusters):
                x.append(backbone_features[cluster])
                coords.append(self.input.coords[cluster])


                # print('i',i)
                # print('cluster',cluster)
                # print('cluster.shape[0]',cluster.shape[0])
                # print('torch.ones(cluster.shape[0])',torch.ones(cluster.shape[0]))


                batch.append(i * torch.ones(cluster.shape[0]))
                pos.append(self.input.pos[cluster])
            batch_cluster = Data(x=torch.cat(x), coords=torch.cat(coords), batch=torch.cat(batch),)
            #print('batch_cluster',batch_cluster.batch)
            #print('batch_cluster',batch_cluster.coords)

            # Voxelise if required
            if self._voxelizer:
                batch_cluster.pos = torch.cat(pos)
                batch_cluster = batch_cluster.to(self.device)
                batch_cluster = self._voxelizer(batch_cluster)

            # Score
            batch_cluster = batch_cluster.to("cpu")
            #print('batch_cluster',batch_cluster)
            if self._scorer_type == "MLP":
                score_backbone_out = self.ScorerMLP(batch_cluster.x.to(self.device))
                cluster_feats = scatter(
                    score_backbone_out, batch_cluster.batch.long().to(self.device), dim=0, reduce="max"
                )
            elif self._scorer_type == "encoder":
                score_backbone_out = self.ScorerEncoder(batch_cluster)
                cluster_feats = score_backbone_out.x
            else:
                score_backbone_out , _ = self.ScorerUnet(batch_cluster) #！！！！ 多增加一个_
                #print('score_backbone_out',score_backbone_out)
                if self.mask_supervise:
                    mask_scores = self.MaskScore(score_backbone_out.x) # [point num of all proposals (voxelized), 1]
                    
                    if self.use_mask_filter_score_feature and epoch > self.use_mask_filter_score_feature_start_epoch:
                        mask_index_select = torch.ones_like(mask_scores)
                        mask_index_select[torch.sigmoid(mask_scores) < self.mask_filter_score_feature_thre] = 0.
                        score_backbone_out.x = score_backbone_out.x * mask_index_select
                    # mask_scores = mask_scores[batch_cluster.inverse_indices] # [point num of all proposals, 1]
                #print('score_backbone_out',score_backbone_out)
                cluster_feats = scatter(
                    score_backbone_out.x, batch_cluster.batch.long().to(self.device), dim=0, reduce="max"
                ) # [num_cluster, 16]

            cluster_scores = self.ScorerHead(cluster_feats).squeeze(-1) # [num_cluster, 1]
            
        else:
            # Use semantic certainty as cluster confidence
            with torch.no_grad():
                cluster_semantic = []
                batch = []
                for i, cluster in enumerate(all_clusters):
                    cluster_semantic.append(semantic_logits[cluster, :])
                    batch.append(i * torch.ones(cluster.shape[0]))
                cluster_semantic = torch.cat(cluster_semantic)
                batch = torch.cat(batch)
                cluster_semantic = scatter(cluster_semantic, batch.long().to(self.device), dim=0, reduce="mean")
                cluster_scores = torch.max(torch.exp(cluster_semantic), 1)[0]
        return cluster_scores, mask_scores
 
    def _compute_score_batch(self, epoch, all_clusters, cluster_type, backbone_features, semantic_logits):
        """ Score the clusters """
        mask_scores = None
        cluster_scores = torch.zeros(len(all_clusters)).to(self.device)
        cluster_type_unique = torch.unique(cluster_type)
        for type_i in cluster_type_unique:
            type_mask_l = cluster_type == type_i
            type_mask_l = torch.where(type_mask_l)[0]
            if self._scorer_type: # unet
                # Assemble batches
                x = [] # backbone features
                coords = [] # input coords
                batch = [] 
                pos = []
                for i, mask_i in enumerate(type_mask_l):
                    cluster = all_clusters[mask_i]
                    #for i, cluster in enumerate(all_clusters):
                    x.append(backbone_features[cluster])
                    coords.append(self.input.coords[cluster])
                    batch.append(i * torch.ones(cluster.shape[0]))
                    pos.append(self.input.pos[cluster])
                batch_cluster = Data(x=torch.cat(x), coords=torch.cat(coords), batch=torch.cat(batch),)

                # Voxelise if required
                if self._voxelizer:
                    batch_cluster.pos = torch.cat(pos)
                    batch_cluster = batch_cluster.to(self.device)
                    batch_cluster = self._voxelizer(batch_cluster)

                # Score
                batch_cluster = batch_cluster.to("cpu")
                if self._scorer_type == "MLP":
                    score_backbone_out = self.ScorerMLP(batch_cluster.x.to(self.device))
                    cluster_feats = scatter(
                        score_backbone_out, batch_cluster.batch.long().to(self.device), dim=0, reduce="max"
                    )
                elif self._scorer_type == "encoder":
                    score_backbone_out = self.ScorerEncoder(batch_cluster)
                    cluster_feats = score_backbone_out.x
                else:
                    score_backbone_out = self.ScorerUnet(batch_cluster)
                    if self.mask_supervise:
                        mask_scores = self.MaskScore(score_backbone_out.x) # [point num of all proposals (voxelized), 1]
                        
                        if self.use_mask_filter_score_feature and epoch > self.use_mask_filter_score_feature_start_epoch:
                            mask_index_select = torch.ones_like(mask_scores)
                            mask_index_select[torch.sigmoid(mask_scores) < self.mask_filter_score_feature_thre] = 0.
                            score_backbone_out.x = score_backbone_out.x * mask_index_select
                        # mask_scores = mask_scores[batch_cluster.inverse_indices] # [point num of all proposals, 1]
                    
                    cluster_feats = scatter(
                        score_backbone_out.x, batch_cluster.batch.long().to(self.device), dim=0, reduce="max"
                    ) # [num_cluster, 16]

                cluster_scores[type_mask_l] = self.ScorerHead(cluster_feats).squeeze(-1) # [num_cluster, 1]
                
            else:
                # Use semantic certainty as cluster confidence
                with torch.no_grad():
                    cluster_semantic = []
                    batch = []
                    for i, cluster in enumerate(all_clusters):
                        cluster_semantic.append(semantic_logits[cluster, :])
                        batch.append(i * torch.ones(cluster.shape[0]))
                    cluster_semantic = torch.cat(cluster_semantic)
                    batch = torch.cat(batch)
                    cluster_semantic = scatter(cluster_semantic, batch.long().to(self.device), dim=0, reduce="mean")
                    cluster_scores = torch.max(torch.exp(cluster_semantic), 1)[0]
        return cluster_scores, mask_scores

    def _compute_real_score(self, epoch, all_clusters, cluster_type, backbone_features, semantic_logits):
        
        mask_scores = None
        cluster_scores = torch.zeros(len(all_clusters))
        if self.input.num_instances>0:
            ious = instance_ious(
                    all_clusters,
                    None,
                    self.input.instance_labels.to(self.device),
                    self.input.batch.to(self.device),
                    None,
                    cal_iou_based_on_mask=False
                )
            ious = ious.max(1)[0]
            min_iou_threshold = 0 #0.25
            max_iou_threshold = 1 #0.75
            lower_mask = ious < min_iou_threshold
            higher_mask = ious > max_iou_threshold
            middle_mask = torch.logical_and(torch.logical_not(lower_mask), torch.logical_not(higher_mask))
            assert torch.sum(lower_mask + higher_mask + middle_mask) == ious.shape[0]
            cluster_scores = torch.zeros_like(ious)
            iou_middle = ious[middle_mask]
            cluster_scores[higher_mask] = 1
            cluster_scores[middle_mask] = (iou_middle - min_iou_threshold) / (max_iou_threshold - min_iou_threshold)
        return cluster_scores, mask_scores
    
    def _compute_loss(self, epoch):
        # Semantic loss
        



        attr = getattr(self, 'weight_classes', None)
        if self._weight_per_point != None:
            if self._weight_per_point == 'height':
                # add weights for each point
                above_height = self.raw_pos[:,-1]-self.raw_pos[:,-1].min()
                sample_weight = above_height/(above_height.mean()+np.finfo(np.float64).eps)
                sample_weight = torch.exp(-sample_weight)
                #sample_weight = torch.empty((self.labels.y).to(torch.int64).size()).fill_(0.1)
                self.semantic_loss = torch.nn.functional.nll_loss(
                        self.output.semantic_logits, (self.labels.y).to(torch.int64), ignore_index=IGNORE_LABEL, reduction='none'
                    )
                self.semantic_loss = self.semantic_loss * sample_weight
                self.semantic_loss = self.semantic_loss.mean()
        elif attr is not None:
            self.semantic_loss = torch.nn.functional.nll_loss(
                self.output.semantic_logits, (self.labels.y).to(torch.int64), weight=self.weight_classes, ignore_index=IGNORE_LABEL
            )
        else:
            
            self.semantic_loss = torch.nn.functional.nll_loss(
                self.output.semantic_logits, (self.labels.y).to(torch.int64), ignore_index=IGNORE_LABEL
            )
        
        self.loss = self.opt.loss_weights.semantic * self.semantic_loss
            

        ######  ！！！！！！！！！！！！为了节省内存注释掉    
        if self.use_binary_loss:
            bi_y = self.labels.y.detach().clone()
            bi_y[(bi_y[..., None] == self._stuff_classes[1:].to(self.device)).any(-1)] = 0 
            bi_y[(bi_y[..., None] == self._thing_classes.to(self.device)).any(-1)] = 1 
            #self.output.bi_semantic_logits = 0
            self.semantic_loss_bi = torch.nn.functional.nll_loss(
                    self.output.bi_semantic_logits, (bi_y).to(torch.int64), ignore_index=IGNORE_LABEL
                )
            self.loss += self.opt.loss_weights.semantic * self.semantic_loss_bi
        
        # Offset loss
        self.input.instance_mask = self.input.instance_mask.to(self.device)
        self.input.vote_label = self.input.vote_label.to(self.device)
        offset_losses = offset_loss(
            self.output.offset_logits[self.input.instance_mask],
            self.input.vote_label[self.input.instance_mask],
            torch.sum(self.input.instance_mask),
        )
        for loss_name, loss in offset_losses.items():
            setattr(self, loss_name, loss)
            self.loss += self.opt.loss_weights[loss_name] * loss
        
########################################################################################

        # # Embed loss
        self.input.instance_labels = self.input.instance_labels.to(self.device)
        self.input.batch = self.input.batch.to(self.device)


        discriminative_losses = discriminative_loss(
            self.output.embed_logits[self.input.instance_mask],
            self.input.instance_labels[self.input.instance_mask],
            self.input.batch[self.input.instance_mask].to(self.device),
            self.opt.embed_dim
            )

        for loss_name, loss in discriminative_losses.items():
            setattr(self, loss_name, loss)
         
            if loss_name=="ins_loss":
                self.loss = self.loss + self.opt.loss_weights.embedding_loss * loss


###########################################################################################################

        if self.output.mask_scores is not None:
            mask_scores_sigmoid = torch.sigmoid(self.output.mask_scores).squeeze()
        else:
            mask_scores_sigmoid = None
            
        # Calculate iou between each proposal and each GT instance
        if epoch > self.opt.prepare_epoch and self.use_score_net:
            if self.cal_iou_based_on_mask and (epoch > self.cal_iou_based_on_mask_start_epoch):
                ious = instance_ious(
                    self.output.clusters,
                    self.output.cluster_scores,
                    self.input.instance_labels,
                    self.input.batch,
                    mask_scores_sigmoid,
                    cal_iou_based_on_mask=True
                )
            else:
                ious = instance_ious(
                    self.output.clusters,
                    self.output.cluster_scores,
                    self.input.instance_labels,
                    self.input.batch,
                    mask_scores_sigmoid,
                    cal_iou_based_on_mask=False
                )
        # Score loss
        if self.output.cluster_scores is not None and self._scorer_type:
            self.score_loss = instance_iou_loss(
                ious,
                self.output.clusters,
                self.output.cluster_scores,
                self.input.instance_labels.to(self.device),
                self.input.batch.to(self.device),
                min_iou_threshold=self.opt.min_iou_threshold,
                max_iou_threshold=self.opt.max_iou_threshold,
            )
            self.loss += self.score_loss * self.opt.loss_weights["score_loss"]

        # Mask loss
        if self.output.mask_scores is not None and self.mask_supervise:
            self.mask_loss = mask_loss(
                ious,
                self.output.clusters,
                mask_scores_sigmoid,
                self.input.instance_labels.to(self.device),
                self.input.batch.to(self.device),
            )
            self.loss += self.mask_loss * self.opt.loss_weights["mask_loss"]



        ################################ 新的损失函数


        for loss_name, loss in self.output.losses.items():
            setattr(self, loss_name, loss)
            self.loss = self.loss + self.opt.loss_weights.bbox_loss * loss
        


        ####################################################

    def backward(self, epoch):
        """Calculate losses, gradients, and update network weights; called in every training iteration"""
        self._compute_loss(epoch)
        self.loss.backward()

    ################################### 新增 用于评估

    def cal_loss(self,epoch):
        self._compute_loss(epoch)


    ####################################

    def _dump_visuals(self, epoch):
        if random.random(): # < self.opt.vizual_ratio:
            if not hasattr(self, "visual_count"):
                self.visual_count = 0
            data_visual = Data(
                pos=self.raw_pos, y=self.input.y, instance_labels=self.input.instance_labels, batch=self.input.batch, vote_label=self.labels.vote_label
            )
            data_visual.semantic_pred = torch.max(self.output.semantic_logits, -1)[1]
            data_visual.vote = self.output.offset_logits
            nms_idx = self.output.get_instances()
            if self.output.clusters is not None:
                data_visual.clusters = [self.output.clusters[i].cpu() for i in nms_idx]
                data_visual.cluster_type = self.output.cluster_type[nms_idx]
            if not os.path.exists("viz"):
                os.mkdir("viz")
            if not os.path.exists("viz/epoch_%i" % (epoch)):
                os.mkdir("viz/epoch_%i" % (epoch))
            #torch.save(data_visual.to("cpu"), "viz/data_e%i_%i.pt" % (epoch, self.visual_count))
            batch_size = torch.unique(data_visual.batch)
            for s in batch_size:
                print(s)
                batch_mask = data_visual.batch == s
                example_name='example_{:d}'.format(self.visual_count)
                val_name = join("viz", "epoch_"+str(epoch), example_name)
                write_ply(val_name,
                            [data_visual.pos[batch_mask].detach().cpu().numpy(), 
                            data_visual.y[batch_mask].detach().cpu().numpy().astype('int32'),
                            data_visual.instance_labels[batch_mask].detach().cpu().numpy().astype('int32'),
                            data_visual.vote_label[batch_mask].detach().cpu().numpy(),
                            data_visual.pos[batch_mask].detach().cpu().numpy()+data_visual.vote_label[batch_mask].detach().cpu().numpy()
                            ],
                            ['x', 'y', 'z', 'sem_label', 'ins_label','offset_x', 'offset_y', 'offset_z', 'center_x', 'center_y', 'center_z'])
                
            self.visual_count += 1


    ##########################################################################  新增sphe和td3d的函数
        

    def forward_train(self,
        x, # 直接使用backbone_feature就行
        targets, # 实例标签和语义标签
        gt_bboxes, # 包围盒的标签
        gt_labels, # 也是一个语义标签
        batch_ins_label,
        batch_size,
        epoch, # 临时增加
        raw_pos):
        
        #print('x是',len(x[0]))
        # print('targets是',len(targets))
        # print('gt_labels是',gt_labels)
        # print('gt_bboxes是',gt_bboxes)
        bbox_preds, cls_preds, locations = self._forward_first(x, raw_pos)
        #print('cls_preds',len(cls_preds[0][0]))

        #print('locations',locations[0][0].shape,locations[0][1].shape,locations[0][2].shape,locations[0][3].shape)


        losses = self._loss_first(bbox_preds, cls_preds, locations, 
                            gt_bboxes, gt_labels, batch_ins_label , batch_size)
        
        #### 多增加bbox_list_test
        bbox_list , bbox_list_test = self._get_bboxes_train(bbox_preds, cls_preds, locations, gt_bboxes, gt_labels, batch_ins_label , batch_size, self.test_cfg)
        # print('bbox_list',bbox_list)
        # print('bbox_list_test',bbox_list_test)


        assigned_bbox_list = []
        for i in range(len(bbox_list)):
            assigned_ids = self.second_assigner.assign(bbox_list[i][0], gt_bboxes[i])
            
            gt_idxs = bbox_list[i][2]
           
            gt_idxs[gt_idxs != assigned_ids] = -1

            boxes = bbox_list[i][0][gt_idxs != -1]
            scores = bbox_list[i][1][gt_idxs != -1]
            gt_idxs = gt_idxs[gt_idxs != -1]

            if len(boxes) != 0:
                
                gt_idxs_one_hot = torch.nn.functional.one_hot(gt_idxs)
                mask, idxs = torch.topk(gt_idxs_one_hot, min(self.num_rois, len(boxes)), 0)
                sampled_boxes = LiDARInstance3DBoxes(boxes.tensor[idxs].view(-1, 7), with_yaw=gt_bboxes[i].with_yaw)
                sampled_scores = scores[idxs].view(-1)
                sampled_gt_idxs = gt_idxs[idxs].view(-1)
                mask = mask.view(-1).bool()
                assigned_bbox_list.append((sampled_boxes[mask],
                                           sampled_scores[mask],
                                           sampled_gt_idxs[mask]))
                
            else:
                
                assigned_bbox_list.append((boxes,
                                           scores,
                                           gt_idxs))


        # preds, targets, feats.coordinates[:, 0].long(), ids[0], rois[0], scores[0], labels[0]
        cls_preds, targets, v2r, r2scene, rois, scores, gt_idxs = self._forward_second(x[0], targets, assigned_bbox_list, locations) # 这里cls_preds的点数比原始输入少是因为其将背景点给消除了
        losses.update(self._loss_second(cls_preds, targets, v2r, r2scene, rois, gt_idxs,
                                        gt_bboxes, gt_labels, batch_size))
        
        

        ##################################################### test

        # bbox_preds, cls_preds, locations = self._forward_first(x)
        # bbox_list_test = self._get_bboxes_test(bbox_preds, cls_preds, locations, self.test_cfg,batch_size)



        cluster=None
        rois_test=None

        if self.use_score_net: # and epoch > self.opt.prepare_epoch:
            if epoch > self.opt.prepare_epoch:   # Active by default epoch > -1: #

                
                inverse_mapping = torch.arange(len(x[0])).long().cuda()
                src_idxs = torch.arange(0, x[0].features.shape[0]).to(inverse_mapping.device)
                src_idxs = src_idxs.unsqueeze(1).expand(src_idxs.shape[0], 2)
                cls_preds_test, idxs_test, v2r_test, r2scene_test, rois_test, scores_test, labels_test = self._forward_second_test(x[0], src_idxs, bbox_list_test, locations)

                results = self._get_instances(cls_preds_test[:, -1], idxs_test[:, 0], v2r_test, r2scene_test, scores_test, labels_test, inverse_mapping, batch_size)

                cluster = self.cluster_from_results(results,batch_size)

        else:
            with torch.no_grad():
                if epoch % 1 == 0:
                    inverse_mapping = torch.arange(len(x[0])).long().cuda()
                    src_idxs = torch.arange(0, x[0].features.shape[0]).to(inverse_mapping.device)
                    src_idxs = src_idxs.unsqueeze(1).expand(src_idxs.shape[0], 2)
                    cls_preds_test, idxs_test, v2r_test, r2scene_test, rois_test, scores_test, labels_test = self._forward_second_test(x[0], src_idxs, bbox_list_test, locations)

                    results = self._get_instances(cls_preds_test[:, -1], idxs_test[:, 0], v2r_test, r2scene_test, scores_test, labels_test, inverse_mapping, batch_size)

                    cluster = self.cluster_from_results(results,batch_size)

        
        #print('rois_test',rois_test)


        #print('cluster',len(cluster))
        # print('results',results)
        # print('results[0]',results[0].shape)
        # print('results[1]',results[1].shape)
        # print('results[2]',results[2].shape)
        # print('results[3]',results[3].shape)

        return losses , cluster , rois_test




    #################################################

    def _forward_first_single(self, x, raw_pos):
        
        reg_pred = torch.exp(self.reg_conv(x).features)
        cls_pred = self.cls_conv(x).features

        reg_preds, cls_preds, locations = [], [], []
        for permutation in x.decomposition_permutations:
            reg_preds.append(reg_pred[permutation])
            cls_preds.append(cls_pred[permutation])
            locations.append(raw_pos[permutation])

            #locations.append(x.coordinates[permutation][:, 1:] * self.voxel_size) # 这里的0.2是体素的大小 先注释掉

        return reg_preds, cls_preds, locations


    def _forward_first(self, x, raw_pos):
        reg_preds, cls_preds, locations = [], [], []
        for i in range(len(x)):
            reg_pred, cls_pred, point = self._forward_first_single(x[i], raw_pos)
            reg_preds.append(reg_pred)
            cls_preds.append(cls_pred)
            locations.append(point)
        return reg_preds, cls_preds, locations


    ###################################################

    ##############################################

    def _loss_first_single(self,
                     bbox_preds,
                     cls_preds,
                     points,
                     gt_bboxes,
                     gt_labels,
                     gt_instance, # 多增加！！！！！！！！！！！！！

                     ):
        
        # 直观影响是使用多少个点去估测检测框，与参数top_pts_threshold有较大关系
        assigned_ids = self.first_assigner.assign(points, gt_bboxes, gt_labels, gt_instance) #多增加！！！！！！！
        #print('assigned_ids',assigned_ids.shape)
        
        bbox_preds = torch.cat(bbox_preds)
        cls_preds = torch.cat(cls_preds)
        points = torch.cat(points)

        # cls loss
        n_classes = cls_preds.shape[1]
        pos_mask = assigned_ids >= 0     # 仅有少数点满足条件
        cls_targets = torch.where(pos_mask, gt_labels[assigned_ids], n_classes)
        avg_factor = max(pos_mask.sum(), 1)
        cls_loss = self.cls_loss(cls_preds, cls_targets, avg_factor=avg_factor)

        # bbox loss
        pos_bbox_preds = bbox_preds[pos_mask]
        if pos_mask.sum() > 0:
            pos_points = points[pos_mask]
            pos_bbox_preds = bbox_preds[pos_mask]
            bbox_targets = torch.cat((gt_bboxes.gravity_center, gt_bboxes.tensor[:, 3:]), dim=1)
            pos_bbox_targets = bbox_targets.to(points.device)[assigned_ids][pos_mask]
            pos_bbox_targets = torch.cat((
                pos_bbox_targets[:, :3],
                pos_bbox_targets[:, 3:6] + self.padding,
                pos_bbox_targets[:, 6:]), dim=1)
            if pos_bbox_preds.shape[1] == 6:
                pos_bbox_targets = pos_bbox_targets[:, :6]


            bbox_loss = self.bbox_loss(self._bbox_to_loss(self._bbox_pred_to_bbox(pos_points, pos_bbox_preds)),self._bbox_to_loss(pos_bbox_targets))

        else:
            bbox_loss = pos_bbox_preds.sum()
        return bbox_loss, cls_loss


    def _loss_first(self, bbox_preds, cls_preds, points,
              gt_bboxes, gt_labels, gt_instance, batch_size): # 多增加！！！！！！！！
        bbox_losses, cls_losses = [], []
        for i in range(batch_size):
            bbox_loss, cls_loss = self._loss_first_single(
                bbox_preds=[x[i] for x in bbox_preds],
                cls_preds=[x[i] for x in cls_preds],
                points=[x[i] for x in points],
                gt_bboxes=gt_bboxes[i],
                gt_labels=gt_labels[i],
                gt_instance = gt_instance[i])  #多增加！！！！！！！！！！
            bbox_losses.append(bbox_loss)
            cls_losses.append(cls_loss)
        return dict(bbox1_loss=torch.mean(torch.stack(bbox_losses)),
                    cls1_loss=torch.mean(torch.stack(cls_losses)))
    

    ####################################################

    @staticmethod
    def _bbox_pred_to_bbox(points, bbox_pred):
            """Transform predicted bbox parameters to bbox.
            Args:
                points (Tensor): Final locations of shape (N, 3)
                bbox_pred (Tensor): Predicted bbox parameters of shape (N, 6)
                    or (N, 8).
            Returns:
                Tensor: Transformed 3D box of shape (N, 6) or (N, 7).
            """
            if bbox_pred.shape[0] == 0:
                return bbox_pred

            x_center = points[:, 0] + (bbox_pred[:, 1] - bbox_pred[:, 0]) / 2
            y_center = points[:, 1] + (bbox_pred[:, 3] - bbox_pred[:, 2]) / 2
            z_center = points[:, 2] + (bbox_pred[:, 5] - bbox_pred[:, 4]) / 2

            # dx_min, dx_max, dy_min, dy_max, dz_min, dz_max -> x, y, z, w, l, h
            base_bbox = torch.stack([
                x_center,
                y_center,
                z_center,
                bbox_pred[:, 0] + bbox_pred[:, 1],
                bbox_pred[:, 2] + bbox_pred[:, 3],
                bbox_pred[:, 4] + bbox_pred[:, 5],
            ], -1)

            # axis-aligned case
            if bbox_pred.shape[1] == 6:
                return base_bbox

            # rotated case: ..., sin(2a)ln(q), cos(2a)ln(q)
            scale = bbox_pred[:, 0] + bbox_pred[:, 1] + \
                    bbox_pred[:, 2] + bbox_pred[:, 3]
            q = torch.exp(
                torch.sqrt(
                    torch.pow(bbox_pred[:, 6], 2) + torch.pow(bbox_pred[:, 7], 2)))
            alpha = 0.5 * torch.atan2(bbox_pred[:, 6], bbox_pred[:, 7])
            return torch.stack(
                (x_center, y_center, z_center, scale / (1 + q), scale /
                (1 + q) * q, bbox_pred[:, 5] + bbox_pred[:, 4], alpha),
                dim=-1)
    
    @staticmethod
    def _bbox_to_loss(bbox):
        """Transform box to the axis-aligned or rotated iou loss format.
        Args:
            bbox (Tensor): 3D box of shape (N, 6) or (N, 7).
        Returns:
            Tensor: Transformed 3D box of shape (N, 6) or (N, 7).
        """
        # rotated iou loss accepts (x, y, z, w, h, l, heading)
        if bbox.shape[-1] != 6:
            return bbox

        # axis-aligned case: x, y, z, w, h, l -> x1, y1, z1, x2, y2, z2
        return torch.stack(
            (bbox[..., 0] - bbox[..., 3] / 2, bbox[..., 1] - bbox[..., 4] / 2,
                bbox[..., 2] - bbox[..., 5] / 2, bbox[..., 0] + bbox[..., 3] / 2,
                bbox[..., 1] + bbox[..., 4] / 2, bbox[..., 2] + bbox[..., 5] / 2),
            dim=-1)





    #####################################################
    
    def _get_bboxes_train(self, bbox_preds, cls_preds, locations, gt_bboxes, gt_labels, gt_instance, batch_size, cfg): # 多增加!!!!!!!!!
        results = []
        results_test = []
        for i in range(batch_size):
            result, result_test = self._get_bboxes_single_train(
                bbox_preds=[x[i] for x in bbox_preds],
                cls_preds=[x[i] for x in cls_preds],
                locations=[x[i] for x in locations],
                gt_bboxes=gt_bboxes[i],
                gt_labels=gt_labels[i],
                gt_instance=gt_instance[i],
                cfg=cfg)
            results.append(result)
            results_test.append(result_test)
        return results , results_test


    def _get_bboxes_single_train(self, bbox_preds, cls_preds, locations, gt_bboxes, gt_labels, gt_instance, cfg): # 多增加！！！！！！
        assigned_ids = self.first_assigner.assign(locations, gt_bboxes, gt_labels, gt_instance) # 多增加！！！！！！
        scores = torch.cat(cls_preds).sigmoid()
        bbox_preds = torch.cat(bbox_preds)
        locations = torch.cat(locations)


        #################################### 为了test新增加

        scores_test = scores.clone().detach()
        bbox_preds_test = bbox_preds.clone().detach()
        locations_test = locations.clone().detach()
        max_scores_test, _ = scores_test.max(dim=1)
        #print('len(scores_test)',len(scores_test))
        
        if len(scores_test) > cfg['nms_pre'] > 0:
            _, ids = max_scores_test.topk(cfg['nms_pre'])
            bbox_preds_test = bbox_preds_test[ids]
            scores_test = scores_test[ids]
            locations_test = locations_test[ids]

        boxes_test = self._bbox_pred_to_bbox(locations_test, bbox_preds_test)
        boxes_test = torch.cat((
            boxes_test[:, :3],
            boxes_test[:, 3:6] - self.padding,
            boxes_test[:, 6:]), dim=1)
        # print('boxes_test',boxes_test)
        # print('scores_test',scores_test)
        boxes_test, scores_test, labels_test = self._nms(boxes_test, scores_test, cfg)



        #####################################




        pos_mask = assigned_ids >= 0
        scores = scores[pos_mask]
        bbox_preds = bbox_preds[pos_mask]
        locations = locations[pos_mask]
        assigned_ids = assigned_ids[pos_mask]

        max_scores, _ = scores.max(dim=1)
        # print('locations',len(locations))
        # print('bbox_preds',len(bbox_preds))
        boxes = self._bbox_pred_to_bbox(locations, bbox_preds)
        boxes = torch.cat((
            boxes[:, :3],
            boxes[:, 3:6] - self.padding,
            boxes.new_zeros(boxes.shape[0], 1)), dim=1)
        boxes = LiDARInstance3DBoxes(boxes,
                                        with_yaw=False,
                                        origin=(.5, .5, .5))
        return (boxes, max_scores, assigned_ids), (boxes_test, scores_test, labels_test)




    #####################################################


    def _forward_second(self, x, targets, bbox_list, locations):
        rois = [b[0] for b in bbox_list] #包围盒的坐标
        scores = [b[1] for b in bbox_list] # 包围盒对应的语义类别(应该都是树)
        labels = [b[2] for b in bbox_list] # ？分配给真实包围盒的索引
        levels = [torch.zeros(len(b[0])) for b in bbox_list] # ？每个包围盒的级别

        # print('rois',rois)
        # print('scores',scores)
        # print('labels',labels)
        # print('levels',levels)

        
        feats_with_targets = ME.SparseTensor(torch.cat((x.features, targets), axis=1), x.coordinates)

        # print('x',len(x))
        # print('feats_with_targets',len(feats_with_targets))


        tensors, ids, rois, scores, labels = self.roi_extractor.extract([feats_with_targets], levels, rois, scores, labels, locations)

        #print('tensors',tensors)
        # 如果tensor全为空可能以下会报错
        if tensors[0].features.shape[0] == 0:
            return (targets.new_zeros((0, 1)),
                    targets.new_zeros((0, 1)),
                    targets.new_zeros(0),
                    targets.new_zeros(0),
                    [targets.new_zeros((0, 7)) for i in range(len(bbox_list))],
                    [targets.new_zeros(0) for i in range(len(bbox_list))],
                    [targets.new_zeros(0) for i in range(len(bbox_list))])
        

        feats = ME.SparseTensor(tensors[0].features[:, :-2], tensors[0].coordinates)
        targets = tensors[0].features[:, -2:]

        # 暂时注释掉
        preds = self.unet(feats).features
        #preds = self.unet(feats.features)


        #print('preds',preds)
        return preds, targets, feats.coordinates[:, 0].long(), ids[0], rois[0], scores[0], labels[0]





    

    def _forward_second_test(self, x, targets, bbox_list, locations):
        rois = [b[0] for b in bbox_list] #包围盒的坐标
        scores = [b[1] for b in bbox_list] # 包围盒对应的语义类别(应该都是树)
        labels = [b[2] for b in bbox_list] # ？分配给真实包围盒的索引
        levels = [torch.zeros(len(b[0])) for b in bbox_list] # ？每个包围盒的级别

        # print('rois',rois)
        # print('scores',scores)
        # print('labels',labels)
        # print('levels',levels)

        
        feats_with_targets = ME.SparseTensor(torch.cat((x.features, targets), axis=1), x.coordinates)

        # print('x',len(x))
        # print('feats_with_targets',len(feats_with_targets))


        tensors, ids, rois, scores, labels = self.roi_extractor.extract([feats_with_targets], levels, rois, scores, labels, locations)

        #print('tensors',tensors)
        # 如果tensor全为空可能以下会报错
        if tensors[0].features.shape[0] == 0:
            return (targets.new_zeros((0, 1)),
                    targets.new_zeros((0, 1)),
                    targets.new_zeros(0),
                    targets.new_zeros(0),
                    [targets.new_zeros((0, 7)) for i in range(len(bbox_list))],
                    [targets.new_zeros(0) for i in range(len(bbox_list))],
                    [targets.new_zeros(0) for i in range(len(bbox_list))])
        

        feats = ME.SparseTensor(tensors[0].features[:, :-2], tensors[0].coordinates)
        targets = tensors[0].features[:, -2:]

        with torch.no_grad():
            # 暂时注释掉
            preds = self.unet(feats).features
            # preds = self.unet(feats.features)
        #print('preds',preds)
        return preds, targets, feats.coordinates[:, 0].long(), ids[0], rois[0], scores[0], labels[0]



    #####################################################




    def _loss_second(self, cls_preds, targets, v2r, r2scene, rois, gt_idxs,
                    gt_bboxes, gt_labels, batch_size):
        v2scene = r2scene[v2r]
        inst_losses = []
        for i in range(batch_size):
            inst_loss = self._loss_second_single(
                cls_preds=cls_preds[v2scene == i],
                targets=targets[v2scene == i],
                v2r=v2r[v2scene == i],
                rois=rois[i],
                gt_idxs=gt_idxs[i],
                gt_bboxes=gt_bboxes[i],
                gt_labels=gt_labels[i])
            inst_losses.append(inst_loss)
        return dict(inst1_loss=torch.mean(torch.stack(inst_losses)))

    def _loss_second_single(self, cls_preds, targets, v2r, rois, gt_idxs, gt_bboxes, gt_labels):
        if len(rois) == 0 or cls_preds.shape[0] == 0:
            return cls_preds.sum().float()
        v2r = v2r - v2r.min()
        assert len(torch.unique(v2r)) == len(rois)
        assert torch.all(torch.unique(v2r) == torch.arange(0, v2r.max() + 1).to(v2r.device))
        assert torch.max(gt_idxs) < len(gt_bboxes)

        v2bbox = gt_idxs[v2r.long()]
        assert torch.unique(v2bbox)[0] != -1
        inst_targets = targets[:, 0]
        seg_targets = targets[:, 1]

        seg_preds = cls_preds[:, :-1]
        inst_preds = cls_preds[:, -1]

        labels = v2bbox == inst_targets

        seg_targets[seg_targets == -1] = self.n_classes
        seg_loss = self.cls_loss(seg_preds, seg_targets.long())

        inst_loss = self.inst_loss(inst_preds, labels)
        return inst_loss + seg_loss

###################################################



    def _get_bboxes_single_test(self, bbox_preds, cls_preds, locations, cfg):
        scores = torch.cat(cls_preds).sigmoid()
        bbox_preds = torch.cat(bbox_preds)
        locations = torch.cat(locations)
        max_scores, _ = scores.max(dim=1)

        if len(scores) > cfg['nms_pre'] > 0:
            _, ids = max_scores.topk(cfg['nms_pre'])
            bbox_preds = bbox_preds[ids]
            scores = scores[ids]
            locations = locations[ids]

        boxes = self._bbox_pred_to_bbox(locations, bbox_preds)
        boxes = torch.cat((
            boxes[:, :3],
            boxes[:, 3:6] - self.padding,
            boxes[:, 6:]), dim=1)
        boxes, scores, labels = self._nms(boxes, scores, cfg)
        return boxes, scores, labels

    def _get_bboxes_test(self, bbox_preds, cls_preds, locations, cfg, batch_size):
        results = []
        for i in range(batch_size):
            result = self._get_bboxes_single_test(
                bbox_preds=[x[i] for x in bbox_preds],
                cls_preds=[x[i] for x in cls_preds],
                locations=[x[i] for x in locations],
                cfg=cfg)
            results.append(result)
        return results



    def _nms(self, bboxes, scores, cfg):
        """Multi-class nms for a single scene.
        Args:
            bboxes (Tensor): Predicted boxes of shape (N_boxes, 6) or
                (N_boxes, 7).
            scores (Tensor): Predicted scores of shape (N_boxes, N_classes).
            img_meta (dict): Scene meta data.
        Returns:
            Tensor: Predicted bboxes.
            Tensor: Predicted scores.
            Tensor: Predicted labels.
        """
        n_classes = scores.shape[1]
        yaw_flag = bboxes.shape[1] == 7
        nms_bboxes, nms_scores, nms_labels = [], [], []
        for i in range(n_classes):
            # print('i',i)
            # print('scores[:, i]',scores[:, i])
            ids = scores[:, i] > cfg['score_thr']
            if not ids.any():
                continue

            class_scores = scores[ids, i]
            class_bboxes = bboxes[ids]
            if yaw_flag:
                nms_function = nms3d
            else:
                class_bboxes = torch.cat(
                    (class_bboxes, torch.zeros_like(class_bboxes[:, :1])),
                    dim=1)
                nms_function = nms3d_normal

            nms_ids = nms_function(class_bboxes, class_scores,
                                   cfg['iou_thr'])
            nms_bboxes.append(class_bboxes[nms_ids])
            nms_scores.append(class_scores[nms_ids])
            nms_labels.append(
                bboxes.new_full(
                    class_scores[nms_ids].shape, i, dtype=torch.long))

        if len(nms_bboxes):
            nms_bboxes = torch.cat(nms_bboxes, dim=0)
            nms_scores = torch.cat(nms_scores, dim=0)
            nms_labels = torch.cat(nms_labels, dim=0)
        else:
            nms_bboxes = bboxes.new_zeros((0, bboxes.shape[1]))
            nms_scores = bboxes.new_zeros((0, ))
            nms_labels = bboxes.new_zeros((0, ))

        if yaw_flag:
            box_dim = 7
            with_yaw = True
        else:
            box_dim = 6
            with_yaw = False
            nms_bboxes = nms_bboxes[:, :6]
        nms_bboxes = LiDARInstance3DBoxes(
            nms_bboxes,
            box_dim=box_dim,
            with_yaw=with_yaw,
            origin=(.5, .5, .5))

        return nms_bboxes, nms_scores, nms_labels



#####################################################

    def _get_instances(self, cls_preds, idxs, v2r, r2scene, scores, labels, inverse_mapping, batch_size):
        v2scene = r2scene[v2r]
        results = []
        for i in range(batch_size):
            result = self._get_instances_single(
                cls_preds=cls_preds[v2scene == i],
                idxs=idxs[v2scene == i],
                v2r=v2r[v2scene == i],
                scores=scores[i],
                labels=labels[i],
                inverse_mapping=inverse_mapping)
            results.append(result)
        return results



    def _get_instances_single(self, cls_preds, idxs, v2r, scores, labels, inverse_mapping):
        if scores.shape[0] == 0:
            return inverse_mapping.new_zeros((1, len(inverse_mapping)), dtype=torch.bool)
        
            # 先注释掉，不需要那么多返回值
            # return (inverse_mapping.new_zeros((1, len(inverse_mapping)), dtype=torch.bool),
            #         inverse_mapping.new_tensor([0], dtype=torch.long),
            #         inverse_mapping.new_tensor([0], dtype=torch.float32))

        v2r = v2r - v2r.min()
        assert len(torch.unique(v2r)) == scores.shape[0]
        assert torch.all(torch.unique(v2r) == torch.arange(0, v2r.max() + 1).to(v2r.device))

        cls_preds = cls_preds.sigmoid()
        # print('cls_preds_min',min(cls_preds))
        # print('cls_preds_max',max(cls_preds))
        binary_cls_preds = cls_preds > self.test_cfg['binary_score_thr']
        v2r_one_hot = torch.nn.functional.one_hot(v2r).bool()
        n_rois = v2r_one_hot.shape[1]
        # todo: why convert from float to long here? can it be long or even int32 before this function?
        idxs_expand = idxs.unsqueeze(-1).expand(idxs.shape[0], n_rois).long()
        # todo: can we not convert to ofloat here?
        binary_cls_preds_expand = binary_cls_preds.unsqueeze(-1).expand(binary_cls_preds.shape[0], n_rois)
        cls_preds[cls_preds <= self.test_cfg['binary_score_thr']] = 0
        cls_preds_expand = cls_preds.unsqueeze(-1).expand(cls_preds.shape[0], n_rois)
        idxs_expand[~v2r_one_hot] = inverse_mapping.max() + 1

        # toso: idxs is float. can these tensors be constructed with .new_zeros(..., dtype=bool) ?
        voxels_masks = idxs.new_zeros(inverse_mapping.max() + 2, n_rois, dtype=bool)
        voxels_preds = idxs.new_zeros(inverse_mapping.max() + 2, n_rois)
        voxels_preds = voxels_preds.scatter_(0, idxs_expand, cls_preds_expand)[:-1, :]
        # todo: is it ok that binary_cls_preds_expand is float?
        voxels_masks = voxels_masks.scatter_(0, idxs_expand, binary_cls_preds_expand)[:-1, :]
        scores = scores * voxels_preds.sum(axis=0) / voxels_masks.sum(axis=0)
        points_masks = voxels_masks[inverse_mapping].T.bool()

        # return points_masks, labels, scores # 先注释掉，不需要那么多返回值
        return points_masks



#######################################################


    def cluster_from_results(self, results, batch_size):
        
        cluster = []

        for i in range(batch_size):
            
            result = results[i]
            
            for t in range(result.shape[0]):

                indices = torch.nonzero(result[t,:]).squeeze() 

                if indices.numel() == 0 or indices.shape == torch.Size([]):
                    continue

                cluster.append(indices)

        return cluster






#################################################################



class S3DISAssigner:
    def __init__(self, top_pts_threshold, label2level):
        # top_pts_threshold: per box
        # label2level: list of len n_classes
        self.top_pts_threshold = top_pts_threshold
        self.label2level = label2level

    @torch.no_grad()
    def assign(self, points, gt_bboxes, gt_labels , gt_instance): # 多增加一个gt_instance！！！！！！！！！！
        # print('points is',len(points[0]))
        # print('gt_instance is',len(gt_instance))
        #print('gt_bboxes is',gt_bboxes)
        #print('gt_labels is',gt_labels)
        # -> object id or -1 for each point
        float_max = points[0].new_tensor(1e8) # tensor(100000000., dtype=torch.float64)
        levels = torch.cat([points[i].new_tensor(i, dtype=torch.long).expand(len(points[i])) # tensor([0, 0, 0,  ..., 0, 0, 0]) 表示从backbone中第0层输出的特征，长度和点云的数量一致
                            for i in range(len(points))])
        #print('levels is',levels)
        points = torch.cat(points)
        n_points = len(points) # 点云的数量
        n_boxes = len(gt_bboxes) # 真实检测框的数量
        boxes = torch.cat((gt_bboxes.gravity_center, gt_bboxes.tensor[:, 3:]), dim=1)  # 重新组合检测框 数量与n_boxes一致，前三列变为检测框的重心坐标而非中心坐标（似乎z值进行了变动）
        boxes = boxes.to(points.device).expand(n_points, n_boxes, 7) # 维度是[n_points, n_boxes, 7] , 即点云的数量，检测框的数量，以及检测框中7个参数
        points = points.unsqueeze(1).expand(n_points, n_boxes, 3) # 与上面相似

        # condition 1: fix level for label
        label2level = gt_labels.new_tensor(self.label2level) # 只有levels和label2level相对应才能分配检测框
        #print('label2level is',label2level)

        label_levels = label2level[gt_labels].unsqueeze(0).expand(n_points, n_boxes)
        point_levels = torch.unsqueeze(levels, 1).expand(n_points, n_boxes)
        level_condition = label_levels == point_levels # 比较 只有levels和label2level相对应才能分配检测框
        # print('label_levels is',label_levels)
        # print('point_levels is',point_levels)
        # print('level_condition is',level_condition)

        # condition 2: keep topk location per box by center distance
        center = boxes[..., :3] # 获取检测框的中心点坐标(注意z值已经变化)
        center_distances = torch.sum(torch.pow(center - points, 2), dim=-1) # 大小为n_points*n_boxes 每个点到所有检测框center的欧氏距离
        center_distances = torch.where(level_condition, center_distances, float_max) # 只有一个backbone输出的话应该全为True ，即center_distances不会发生任何改变
        # print('center_distances is',center_distances)
        # print('len(center_distances) is',len(center_distances))
        # print('len(center_distances[1]) is',len(center_distances[1]))
        
        # todo:理解一下什么含义
        #print('center_distances',torch.unique(center_distances))
        # topk_distances 距离检测框中心最近的第self.top_pts_threshold + 1的距离
        topk_distances = torch.topk(center_distances,
                                    min(self.top_pts_threshold + 1, len(center_distances)),
                                    largest=False, dim=0).values[-1]
        
        #print('topk_distances is',topk_distances.unsqueeze(0))
        #print('len(center_distances)',len(center_distances))
        topk_condition = center_distances < topk_distances.unsqueeze(0) # 仅有少数点为True
        

        # condition 3.0: only closest object to point
        center_distances = torch.sum(torch.pow(center - points, 2), dim=-1)
        _, min_inds_ = center_distances.min(dim=1)

        # condition 3: min center distance to box per point
        #print('center_distances qian is',center_distances)
        center_distances = torch.where(topk_condition, center_distances, float_max)
        #print('center_distances hou is',center_distances)
        min_values, min_ids = center_distances.min(dim=1)
        #print('min_values是',min_values)
        min_inds = torch.where(min_values < float_max, min_ids, -1)
        min_inds = torch.where(min_inds == min_inds_, min_ids, -1)

        return min_inds
        #return gt_instance
    

##################################################################

class MaxIoU3DAssigner:
    def __init__(self, threshold):
        # threshold: for positive IoU
        self.threshold = threshold

    def assign(self, rois, gt_bboxes):
        # rois: BaseInstance3DBoxes
        # gt_bboxes: BaseInstance3DBoxes
        # -> object id or -1 for each point
        # print('rois',rois)
        # print('gt_bboxes',gt_bboxes)
        ious = rois.overlaps(rois, gt_bboxes.to(rois.device))
        values, indices = ious.max(dim=1)
        #print('values',values)
        indices = torch.where(values > self.threshold, indices, -1)
        return indices
    

#####################################################################

class Mink3DRoIExtractor:
    def __init__(self, voxel_size, padding, min_pts_threshold):
        # min_pts_threshold: minimal number of points per roi
        self.voxel_size = voxel_size
        self.padding = padding
        self.min_pts_threshold = min_pts_threshold
    
    # per scene and per level
    def _extract_single(self, coordinates, features, voxel_size, rois, scores, labels, locations_level): # coordinates和features代表！！所有点的坐标和特征， rois, scores, labels则代表包围盒的信息
        # coordinates: of shape (n_points, 3)
        # features: of shape (n_points, c)
        # voxel_size: float
        # rois: of shape (n_rois, 7)
        # -> new indices of shape n_new_points
        # -> new coordinates of shape (n_new_points, 3)
        # -> new features of shape (n_new_points, c + 3)
        # -> new rois of shape (n_new_rois, 7)
        # -> new scores of shape (n_new_rois)
        # -> new labels of shape (n_new_rois)
        n_points = len(coordinates) # 点云的点数
        n_boxes = len(rois) # 包围盒的数量
        if n_boxes == 0:
            return (coordinates.new_zeros(0),
                    coordinates.new_zeros((0, 3)),
                    features.new_zeros((0, features.shape[1])),
                    features.new_zeros((0, 7)),
                    features.new_zeros(0),
                    coordinates.new_zeros(0))


        #points = coordinates * self.voxel_size # ？ 点的真实坐标 coordinates为整数，所以points应为浮点型
        points = locations_level.clone().detach()
        #print('points',points.shape)

        points = points.unsqueeze(1).expand(n_points, n_boxes, 3)  # 与s3disassigner类似
        rois = rois.unsqueeze(0).expand(n_points, n_boxes, 7)  # 与s3disassigner类似
        
        face_distances = get_face_distances(points, rois) # 计算每个点到不同包围盒的六个面的距离 # 返回torch.stack((dx_min, dx_max, dy_min, dy_max, dz_min, dz_max), dim=-1) 形状为(n_points, n_boxes, 6)



        # print('n_points',n_points)
        # print('n_boxes',n_boxes)
        # print('face_distances',face_distances.shape)


        inside_condition = face_distances.min(dim=-1).values > 0 # ？只有最小值大于0才能说明点在包围盒里面 形状为(n_points, n_boxes) 里面全是bool型
        min_pts_condition = inside_condition.sum(dim=0) > self.min_pts_threshold # 每个包围盒最少要有min_pts_threshold个点 形状为(n_boxes)表示每个包围盒是否符合条件

        # print('inside_condition',inside_condition)
        # print('min_pts_condition',min_pts_condition)

        inside_condition = inside_condition[:, min_pts_condition]   # 将符合min_pts_condition最小点数的包围盒筛选出来 即去除无效的包围盒
        rois = rois[0, min_pts_condition] # 去除无效的包围盒
        scores = scores[min_pts_condition] # 去除无效的包围盒
        labels = labels[min_pts_condition] # 去除无效的包围盒
        nonzero = torch.nonzero(inside_condition) # 寻找非0元素的索引
        new_coordinates = coordinates[nonzero[:, 0]]  # nonzero[:, 0]为非零元素的行索引 即刷选出点在包围盒的点 返回的new_coordinates即前景点的坐标
        
        # ？ nonzero[:, 1]表示！！（注意每个）每个包围盒中包含着点的索引 ，new_coordinates和features为确定在包围盒内各点的new_coordinates 和features。rois, scores, labels 为去除无效包围盒后的信息
        return nonzero[:, 1], new_coordinates, features[nonzero[:, 0]], rois, scores, labels 

    def extract(self, tensors, levels, rois, scores, labels, locations):  # self.roi_extractor.extract([feats_with_targets], levels, rois, scores, labels)
        # tensors: list[SparseTensor] of len n_levels
        # levels: list[Tensor] of len batch_size;
        #         each of shape n_rois_i
        # rois: list[BaseInstance3DBoxes] of len batch_size;
        #       each of len n_rois_i
        # -> list[SparseTensor] of len n_levels
        # -> list[Tensor] of len n_levels;
        #    contains scene id for each extracted roi
        # -> list[list[BaseInstance3DBoxes]] of len n_levels;
        #    each of len batch_size; just splitted rois
        #    per level and per scene
        box_type = rois[0].__class__ # 包围盒的类型，为LiDARInstance3DBoxes或DepthInstance3DBoxes
        with_yaw = rois[0].with_yaw # 默认为false

        # 似乎将LiDARInstance3DBoxes类转换为tensor类
        for i, roi in enumerate(rois):
            rois[i] = torch.cat((
                roi.gravity_center,
                roi.tensor[:,  3:6] + self.padding,
                roi.tensor[:, 6:]), dim=1)
            
        # print('rois',rois)

        new_tensors, new_ids, new_rois, new_scores, new_labels = [], [], [], [], []  # 进行初始化

        # print('tensors',tensors)

        for level, x in enumerate(tensors): # 遍历[feats_with_targets] 应该只循环一次，因此level为0 x为sparse_tensor
            voxel_size = self.voxel_size * x.tensor_stride[0] # ？用于计算当前层级特征图中每个体素的实际物理尺寸 层级越高，voxel_size越大，tensor的个数越少 不过在本例中 x.tensor_stride[0]=1
            # print('x.tensor_stride',x.tensor_stride)
            # print('x.tensor_stride[0]',x.tensor_stride[0])
            new_coordinates, new_features, new_roi, new_score, new_label, ids = [], [], [], [], [], [] # 进行初始化
            n_rois = 0

            #### 新增加
            locations_level = locations[level]


            for i, (coordinates, features) in enumerate(
                zip(*x.decomposed_coordinates_and_features)): #x.decomposed_coordinates_and_features将稀疏张量的坐标和特征拆开  !!!!  i似乎对应batch_size 按batch_size提取(coordinates, features)

                #print('i',i)
                #print('(coordinates, features)',(coordinates, features))

                roi = rois[i][levels[i] == level]   # ？对应层级进行处理
                score = scores[i][levels[i] == level]  # ？对应层级进行处理
                label = labels[i][levels[i] == level]  # ？对应层级进行处理
                
                new_index, new_coordinate, new_feature, roi, score, label = self._extract_single(
                    coordinates, features, voxel_size, roi, score, label, locations_level[i])
                new_index = new_index + n_rois
                n_rois += len(roi) # 对包围盒不断累加 确保一个批次内new_index是非严格递增的
                new_coordinate = torch.cat((
                    new_index.unsqueeze(1), new_coordinate), dim=1) # new_coordinate第一列每个点所处的包围盒编号 后三列为坐标
                
                # print('new_index',new_index)
                # print('n_rois',n_rois)
                # print('new_coordinate',new_coordinate)

                new_coordinates.append(new_coordinate)
                new_features.append(new_feature)
                ids += [i] * len(roi) # 表示每个包围盒属于一个批次内的第几个 例如[0,0,1,2,2,2,3,3]表示在batch_size=4中，有两个包围盒属于0，一个属于1，三个包围盒属于2，两个包围盒属于3

                # print('ids',ids)
                # print('i',i)
                # print('roi',roi)

                roi = torch.cat((roi[:, :3],
                            roi[:,  3:6] - self.padding,
                            roi[:, 6:]), dim=1)
                new_roi.append(box_type(roi, with_yaw=with_yaw, origin=(.5, .5, .5)))
                new_score.append(score)
                new_label.append(label)

            
            new_tensors.append(ME.SparseTensor(
                torch.cat(new_features),
                torch.cat(new_coordinates).int(), # !!这里原本是float，但是为了避免警告改为int
                tensor_stride=x.tensor_stride))
            
            new_ids.append(x.coordinates.new_tensor(ids))
            new_rois.append(new_roi)
            new_scores.append(new_score)
            new_labels.append(new_label)

        return new_tensors, new_ids, new_rois, new_scores, new_labels
    




def get_face_distances(points, boxes):
    # points: of shape (..., 3)
    # boxes: of shape (..., 7)
    # -> of shape (..., 6): dx_min, dx_max, dy_min, dy_max, dz_min, dz_max
    shift = torch.stack((
        points[..., 0] - boxes[..., 0],
        points[..., 1] - boxes[..., 1],
        points[..., 2] - boxes[..., 2]), dim=-1).permute(1, 0, 2)
    shift = rotation_3d_in_axis(shift, -boxes[0, :, 6], axis=2).permute(1, 0, 2)
    centers = boxes[..., :3] + shift
    dx_min = centers[..., 0] - boxes[..., 0] + boxes[..., 3] / 2
    dx_max = boxes[..., 0] + boxes[..., 3] / 2 - centers[..., 0]
    dy_min = centers[..., 1] - boxes[..., 1] + boxes[..., 4] / 2
    dy_max = boxes[..., 1] + boxes[..., 4] / 2 - centers[..., 1]
    dz_min = centers[..., 2] - boxes[..., 2] + boxes[..., 5] / 2
    dz_max = boxes[..., 2] + boxes[..., 5] / 2 - centers[..., 2]
    return torch.stack((dx_min, dx_max, dy_min, dy_max, dz_min, dz_max), dim=-1)



def rotation_3d_in_axis(points,
                        angles,
                        axis=0,
                        return_mat=False,
                        clockwise=False):
    """Rotate points by angles according to axis.

    Args:
        points (np.ndarray | torch.Tensor | list | tuple ):
            Points of shape (N, M, 3).
        angles (np.ndarray | torch.Tensor | list | tuple | float):
            Vector of angles in shape (N,)
        axis (int, optional): The axis to be rotated. Defaults to 0.
        return_mat: Whether or not return the rotation matrix (transposed).
            Defaults to False.
        clockwise: Whether the rotation is clockwise. Defaults to False.

    Raises:
        ValueError: when the axis is not in range [0, 1, 2], it will
            raise value error.

    Returns:
        (torch.Tensor | np.ndarray): Rotated points in shape (N, M, 3).
    """
    batch_free = len(points.shape) == 2
    if batch_free:
        points = points[None]

    if isinstance(angles, float) or len(angles.shape) == 0:
        angles = torch.full(points.shape[:1], angles)

    assert len(points.shape) == 3 and len(angles.shape) == 1 \
        and points.shape[0] == angles.shape[0], f'Incorrect shape of points ' \
        f'angles: {points.shape}, {angles.shape}'

    assert points.shape[-1] in [2, 3], \
        f'Points size should be 2 or 3 instead of {points.shape[-1]}'

    rot_sin = torch.sin(angles)
    rot_cos = torch.cos(angles)
    ones = torch.ones_like(rot_cos)
    zeros = torch.zeros_like(rot_cos)

    if points.shape[-1] == 3:
        if axis == 1 or axis == -2:
            rot_mat_T = torch.stack([
                torch.stack([rot_cos, zeros, -rot_sin]),
                torch.stack([zeros, ones, zeros]),
                torch.stack([rot_sin, zeros, rot_cos])
            ])
        elif axis == 2 or axis == -1:
            rot_mat_T = torch.stack([
                torch.stack([rot_cos, rot_sin, zeros]),
                torch.stack([-rot_sin, rot_cos, zeros]),
                torch.stack([zeros, zeros, ones])
            ])
        elif axis == 0 or axis == -3:
            rot_mat_T = torch.stack([
                torch.stack([ones, zeros, zeros]),
                torch.stack([zeros, rot_cos, rot_sin]),
                torch.stack([zeros, -rot_sin, rot_cos])
            ])
        else:
            raise ValueError(f'axis should in range '
                             f'[-3, -2, -1, 0, 1, 2], got {axis}')
    else:
        rot_mat_T = torch.stack([
            torch.stack([rot_cos, rot_sin]),
            torch.stack([-rot_sin, rot_cos])
        ])

    if clockwise:
        rot_mat_T = rot_mat_T.transpose(0, 1)

    if points.shape[0] == 0:
        points_new = points
    else:
        points_new = torch.einsum('aij,jka->aik', points, rot_mat_T)

    if batch_free:
        points_new = points_new.squeeze(0)

    if return_mat:
        rot_mat_T = torch.einsum('jka->ajk', rot_mat_T)
        if batch_free:
            rot_mat_T = rot_mat_T.squeeze(0)
        return points_new, rot_mat_T
    else:
        return points_new





