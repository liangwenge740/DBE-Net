import torch
from scipy.spatial import cKDTree
import numpy as np
import copy
from pykdtree.kdtree import KDTree as KDTree2


def find_nearest_point(query_point, points):
    """
    寻找点集中距离给定点最近的点
    时间复杂度：构建树 O(n log n) + 查询 O(log n)
    空间复杂度：O(n)
    
    :param query_point: 目标点 (x, y, z)
    :param points: 点集列表，格式为(m*3)
    :return: (最近点的坐标, 最近的距离)
    """
    # 构建 k-d 树（如果点集静态可以缓存树对象提升性能）
    tree = KDTree2(points)
    
    # 查询最近邻
    distance, index = tree.query(query_point, k=1)
    
    # 返回最近点的坐标和距离
    return index[0], distance[0]


def set_mer(all_clusters, raw_pos, batch, N1 = 2000, r_min = 2, a=1): # N1用来确定哪些是主实例，哪些是碎片实例

    primary_idx = []
    fragment_idx = []

    primary_pos= []
    fragment_pos= []

    primary_batch = []
    fragment_batch = []

    dynamic_r = []

    
    refine_cluster = []


    # 划分主实例和碎片实例
    for i, cluster in enumerate(all_clusters):

        assert len(torch.unique(batch[cluster])) == 1

        if len(cluster) >= N1: # 点数大于N1的为主实例
            primary_idx.append(cluster) # [cluster1, cluster2 ,...,]
            primary_pos.append(torch.mean(raw_pos[cluster],axis=0).cpu().numpy()) # [pos1, pos2, ...,] 注意pos是numpy数组
            primary_batch.append(torch.unique(batch[cluster]).cpu().numpy())

            r_cluster = float(min((torch.max(raw_pos[cluster],axis=0).values - torch.min(raw_pos[cluster],axis=0).values)[0:2])) * a
            dynamic_r.append(r_cluster)
            

        else:
            fragment_idx.append(cluster)
            fragment_pos.append(torch.mean(raw_pos[cluster],axis=0).cpu().numpy())
            fragment_batch.append(torch.unique(batch[cluster]).cpu().numpy())



    # print('主实例的数量',len(primary_idx))
    # print('碎片的数量',len(fragment_idx))


    primary_batch = np.array(primary_batch)
    fragment_batch = np.array(fragment_batch)

    
    dynamic_r_final = [r_min if x < r_min else x for x in dynamic_r]
    #print('dynamic_r_final',dynamic_r_final)


    

    for i in range(len(torch.unique(batch))):

        remain_idx = []
        
        primary_batch_index = np.where(primary_batch==i)[0]
        fragment_batch_index = np.where(fragment_batch==i)[0]


        primary_idx_copy = copy.deepcopy(primary_idx)
        fragment_idx_copy = copy.deepcopy(fragment_idx)
        primary_pos_copy = copy.deepcopy(primary_pos)
        fragment_pos_copy = copy.deepcopy(fragment_pos)
        dynamic_r_final_copy = copy.deepcopy(dynamic_r_final)

        fragment_idx_batch_idx = [fragment_idx_copy[t] for t in fragment_batch_index]
        fragment_pos_batch_idx = [fragment_pos_copy[t] for t in fragment_batch_index]
        primary_pos_batch_idx = [primary_pos_copy[t] for t in primary_batch_index]
        primary_idx_batch_idx = [primary_idx_copy[t] for t in primary_batch_index]
        dynamic_r_final_batch_idx = [dynamic_r_final_copy[t] for t in primary_batch_index]
        

        primary_pos_batch_idx = np.array(primary_pos_batch_idx)
        
        #print('primary_pos_batch_idx',primary_pos_batch_idx)

        if primary_idx_batch_idx != [] and fragment_idx_batch_idx != []:

            for j, fragment in enumerate(fragment_idx_batch_idx):
                #print('fragment_pos_batch_idx[j]',fragment_pos_batch_idx[j])

                idx, distance = find_nearest_point(fragment_pos_batch_idx[j].reshape(-1,3), primary_pos_batch_idx)
                if distance < dynamic_r_final_batch_idx[idx]:
                    #print('在运行set——merge')
                    primary_idx_batch_idx[idx] = torch.unique(torch.cat((primary_idx_batch_idx[idx], fragment),dim=0))
                else:
                    remain_idx.append(fragment)
        elif primary_idx_batch_idx == []:
            for j, fragment in enumerate(fragment_idx_batch_idx):
                remain_idx.append(fragment)
        elif fragment_idx_batch_idx == []:
            pass


        refine_cluster =  refine_cluster + primary_idx_batch_idx + remain_idx
        

    return refine_cluster

    




    


            




