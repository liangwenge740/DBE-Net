from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
import numpy as np
import torch

def pca_feat(cat_feat,n_components=3):
    cat_feat = cat_feat.cpu().detach().numpy()
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(cat_feat)

    pca = PCA(n_components)  
    pca_feat = pca.fit_transform(X_scaled)
    pca_feat = torch.from_numpy(pca_feat)

    return pca_feat.cuda()
