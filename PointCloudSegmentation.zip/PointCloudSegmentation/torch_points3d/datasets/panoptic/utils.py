import numpy as np
import torch
from .base_box3d import BaseInstance3DBoxes
from .depth_box3d import DepthInstance3DBoxes
from .lidar_box3d import LiDARInstance3DBoxes

def set_extra_labels(data, instance_classes, num_max_objects):
    """ Adds extra labels for the instance and object segmentation tasks
    - num_instances: number of instances
    - center_label: [64, 3] on centre per instance
    - instance_labels: [num_points]
    - vote_label: [num_points, 3] displacmenet between each point and the center.
    - instance_mask: [num_points] boolean mask 
    """


    # Initaliase variables
    num_points = data.pos.shape[0]
    semantic_labels = data.y
    #print('semantic_labels',torch.unique(semantic_labels))

    ##remove points thing points without instance ids
    stuff_points = np.full(semantic_labels.size(), True)
    
    for i in instance_classes:
        stuff_points = np.logical_and(stuff_points, semantic_labels!=i)
    stuff_instance_ids = np.unique(data.instance_labels[stuff_points.type(torch.bool)])
    

    # compute votes *AFTER* augmentation
    instances = np.unique(data.instance_labels)
    
    centers = []
    point_votes = torch.zeros([num_points, 3])
    instance_labels = torch.zeros(num_points, dtype=torch.long)
    
    instance_idx = 1

    #####新增一个

    semantic_labels_no_stuff = torch.zeros(num_points, dtype=torch.long)

    #################


    ############新增包围盒

    #bbox = torch.zeros([num_points, 6])
    #center_label_pts = torch.zeros([num_points, 3])

    ####################



    for i_instance in instances:
        ##if the same instance id with stuff points
        if i_instance in stuff_instance_ids:
            continue
        # find all points belong to that instance
        ind = np.where(data.instance_labels == i_instance)[0]
        # find the semantic label
        instance_class = semantic_labels[ind[0]].item()
        if instance_class in instance_classes:  # We keep this instance
            pos = data.pos[ind, :3]
            max_pox = pos.max(0)[0]
            min_pos = pos.min(0)[0]
            center = 0.5 * (min_pos + max_pox)
            point_votes[ind, :] = center - pos
            centers.append(center.clone().detach())
            instance_labels[ind] = instance_idx
            instance_idx += 1


            ########### 新增函数

            semantic_labels_no_stuff[ind] = instance_class



            ###############






    num_instances = len(centers)
    # print('num_instances',num_instances)
    if num_instances > num_max_objects:
        raise ValueError(
            "We have more objects than expected. Please increase the NUM_MAX_OBJECTS variable.")
    data.center_label = torch.zeros((num_max_objects, 3))
    if num_instances:
        data.center_label[:num_instances, :] = torch.stack(centers)

    ####新增列表

    semantic_labels_no_stuff[semantic_labels_no_stuff == 0] = -1
    semantic_labels_no_stuff[semantic_labels_no_stuff != -1] = 0
    data.semantic_labels_no_stuff = semantic_labels_no_stuff
    #print('data.semantic_labels_no_stuff',torch.unique(data.semantic_labels_no_stuff))

    ############

    data.vote_label = point_votes.float()
    data.instance_labels = instance_labels
    data.instance_mask = instance_labels != 0
    data.num_instances = torch.tensor([num_instances])


    ############### 新增
    # print('len(data.semantic_labels_no_stuff)',len(data.semantic_labels_no_stuff))
    #print('len(data.instance_labels)',torch.unique(data.instance_labels))
    # print('unique',torch.unique(data.semantic_labels_no_stuff))

    data.instance_labels_no_stuff = instance_labels.clone().detach()-1
    #print('data.instance_labels_no_stuff',data.instance_labels_no_stuff.shape)
    #print('data.instance_labels_no_stuff',torch.unique(data.instance_labels_no_stuff))


    data.gt_bboxes_3d , data.gt_labels_3d = BboxRecalculation(data.instance_labels_no_stuff, data.pos, data.semantic_labels_no_stuff)

    data.batch_ins_label = (instance_labels.clone().detach()-1).numpy()
    #print('batch_ins_label',data.batch_ins_label.shape)

    # print('data.gt_bboxes_3d是',data.gt_bboxes_3d)
    #print('data.gt_labels_3d是',data.gt_labels_3d.shape)
    
    #######################

    

    return data





######## 新增函数


    #################################

def BboxRecalculation(pts_instance_mask, points, pts_semantic_mask):


    pts_instance_mask = pts_instance_mask.clone().detach()
    #print('pts_instance_mask',torch.unique(pts_instance_mask))

    if torch.sum(pts_instance_mask == -1) != 0:
        pts_instance_mask[pts_instance_mask == -1] = torch.max(pts_instance_mask) + 1
        pts_instance_mask_one_hot = torch.nn.functional.one_hot(pts_instance_mask)[
            :, :-1
        ]
    else:
        pts_instance_mask_one_hot = torch.nn.functional.one_hot(pts_instance_mask)

    points = points.clone().detach()
    points_for_max = points.unsqueeze(1).expand(points.shape[0], pts_instance_mask_one_hot.shape[1], points.shape[1]).clone()
    points_for_min = points.unsqueeze(1).expand(points.shape[0], pts_instance_mask_one_hot.shape[1], points.shape[1]).clone()
    points_for_max[~pts_instance_mask_one_hot.bool()] = float('-inf')
    points_for_min[~pts_instance_mask_one_hot.bool()] = float('inf')
    bboxes_max = points_for_max.max(axis=0)[0]
    bboxes_min = points_for_min.min(axis=0)[0]
    bboxes_sizes = bboxes_max - bboxes_min
    bboxes_centers = (bboxes_max + bboxes_min) / 2
    bboxes = torch.hstack((bboxes_centers, bboxes_sizes, torch.zeros_like(bboxes_sizes[:, :1])))
    #bboxes = bboxes[1:]

    ################
    #nan_mask = torch.isnan(bboxes[:, 0])
    #nan_indices = torch.where(nan_mask)[0] 
    #bboxes = bboxes[~nan_mask]
    ################


    #print('bboxes',bboxes)
    gt_bboxes_3d = LiDARInstance3DBoxes(bboxes, with_yaw=False, origin=(.5, .5, .5))

    #print('gt_bboxes_3d',gt_bboxes_3d)
    #print('pts_semantic_mask',pts_semantic_mask)
    pts_semantic_mask = pts_semantic_mask.clone().detach()
    pts_semantic_mask_expand = pts_semantic_mask.unsqueeze(1).expand(pts_semantic_mask.shape[0], pts_instance_mask_one_hot.shape[1]).clone()
    pts_semantic_mask_expand[~pts_instance_mask_one_hot.bool()] = -1
    assert pts_semantic_mask_expand.max(axis=0)[0].shape[0] != 0
    #gt_labels_3d = pts_semantic_mask_expand.max(axis=0)[0].numpy()
    gt_labels_3d = pts_semantic_mask_expand.max(axis=0)[0].numpy()

    ################
    #gt_labels_3d = gt_labels_3d[~nan_mask]
    #gt_labels_3d = [i-2 for i in gt_labels_3d] 因为是234 所以labellevel是要5行数字
    ################
    #gt_labels_3d = gt_labels_3d[1:]
    #print('gt_labels_3d',gt_labels_3d)
    return gt_bboxes_3d, gt_labels_3d
    
##########################################################
